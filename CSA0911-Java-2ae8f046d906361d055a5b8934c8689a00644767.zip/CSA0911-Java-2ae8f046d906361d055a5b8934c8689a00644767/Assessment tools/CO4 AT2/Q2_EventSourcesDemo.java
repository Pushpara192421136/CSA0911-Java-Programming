import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Q2_EventSourcesDemo extends JFrame {
    private final JTextArea outputArea = new JTextArea(8, 40);

    public Q2_EventSourcesDemo() {
        setTitle("Event Sources Demo");
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        JButton button = new JButton("Click Button");
        JTextField textField = new JTextField(15);
        JCheckBox checkBox = new JCheckBox("Select Checkbox");

        outputArea.setEditable(false);
        outputArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));

        button.addActionListener(e ->
            logEvent(e.getSource(), "ActionEvent (Button click)"));

        textField.addActionListener(e ->
            logEvent(e.getSource(), "ActionEvent (TextField Enter)"));

        checkBox.addItemListener(e ->
            logEvent(e.getSource(), "ItemEvent (Checkbox " +
                (e.getStateChange() == ItemEvent.SELECTED ? "selected" : "deselected") + ")"));

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                logEvent(e.getSource(), "WindowEvent (Window closing)");
                dispose();
                System.exit(0);
            }
        });

        JPanel panel = new JPanel(new FlowLayout());
        panel.add(button);
        panel.add(textField);
        panel.add(checkBox);

        add(panel, BorderLayout.NORTH);
        add(new JScrollPane(outputArea), BorderLayout.CENTER);
        setSize(450, 250);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void logEvent(Object source, String eventType) {
        outputArea.append("Source: " + source.getClass().getSimpleName()
            + " | Type: " + eventType + "\n");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Q2_EventSourcesDemo());
    }
}
