import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;

public class Q4_StudentRecord extends JFrame {
    private final JTextField idField = new JTextField(10);
    private final JTextField nameField = new JTextField(15);
    private final JTextField courseField = new JTextField(15);
    private final JTextArea displayArea = new JTextArea(10, 40);
    private final Map<String, String[]> records = new LinkedHashMap<>();

    public Q4_StudentRecord() {
        setTitle("Student Record Management");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        JPanel formPanel = new JPanel(new GridLayout(3, 2, 5, 5));
        formPanel.setBorder(BorderFactory.createTitledBorder("Student Details"));
        formPanel.add(new JLabel("Student ID:"));
        formPanel.add(idField);
        formPanel.add(new JLabel("Name:"));
        formPanel.add(nameField);
        formPanel.add(new JLabel("Course:"));
        formPanel.add(courseField);

        JButton addBtn = new JButton("Add");
        JButton updateBtn = new JButton("Update");
        JButton deleteBtn = new JButton("Delete");
        JButton displayBtn = new JButton("Display All");

        addBtn.addActionListener(e -> addRecord());
        updateBtn.addActionListener(e -> updateRecord());
        deleteBtn.addActionListener(e -> deleteRecord());
        displayBtn.addActionListener(e -> displayRecords());

        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(addBtn);
        buttonPanel.add(updateBtn);
        buttonPanel.add(deleteBtn);
        buttonPanel.add(displayBtn);

        displayArea.setEditable(false);
        displayArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.add(formPanel, BorderLayout.CENTER);
        topPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(topPanel, BorderLayout.NORTH);
        add(new JScrollPane(displayArea), BorderLayout.CENTER);
        setSize(500, 400);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private String getId() {
        return idField.getText().trim();
    }

    private void addRecord() {
        String id = getId();
        if (id.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter a Student ID.");
            return;
        }
        if (records.containsKey(id)) {
            JOptionPane.showMessageDialog(this, "Record already exists. Use Update.");
            return;
        }
        records.put(id, new String[]{nameField.getText().trim(), courseField.getText().trim()});
        JOptionPane.showMessageDialog(this, "Record added.");
        displayRecords();
    }

    private void updateRecord() {
        String id = getId();
        if (!records.containsKey(id)) {
            JOptionPane.showMessageDialog(this, "Record not found.");
            return;
        }
        records.put(id, new String[]{nameField.getText().trim(), courseField.getText().trim()});
        JOptionPane.showMessageDialog(this, "Record updated.");
        displayRecords();
    }

    private void deleteRecord() {
        String id = getId();
        if (records.remove(id) != null) {
            JOptionPane.showMessageDialog(this, "Record deleted.");
            clearFields();
            displayRecords();
        } else {
            JOptionPane.showMessageDialog(this, "Record not found.");
        }
    }

    private void displayRecords() {
        displayArea.setText("");
        if (records.isEmpty()) {
            displayArea.setText("No records found.");
            return;
        }
        displayArea.append(String.format("%-10s %-20s %-15s%n", "ID", "Name", "Course"));
        displayArea.append("-".repeat(47) + "\n");
        for (Map.Entry<String, String[]> entry : records.entrySet()) {
            displayArea.append(String.format("%-10s %-20s %-15s%n",
                entry.getKey(), entry.getValue()[0], entry.getValue()[1]));
        }
    }

    private void clearFields() {
        idField.setText("");
        nameField.setText("");
        courseField.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Q4_StudentRecord());
    }
}
