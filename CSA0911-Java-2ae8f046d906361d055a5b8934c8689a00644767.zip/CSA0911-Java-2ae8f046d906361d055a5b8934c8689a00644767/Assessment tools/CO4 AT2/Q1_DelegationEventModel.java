import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Q1_DelegationEventModel extends JFrame {
    private final JLabel statusLabel = new JLabel("Interact with the controls below", SwingConstants.CENTER);

    public Q1_DelegationEventModel() {
        setTitle("Delegation Event Model Demo");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        JButton clickButton = new JButton("Click Me");
        JCheckBox agreeCheckBox = new JCheckBox("I agree to the terms");

        clickButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                statusLabel.setText("ActionEvent: Button clicked");
            }
        });

        agreeCheckBox.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                if (e.getStateChange() == ItemEvent.SELECTED) {
                    statusLabel.setText("ItemEvent: Checkbox selected");
                } else {
                    statusLabel.setText("ItemEvent: Checkbox deselected");
                }
            }
        });

        JPanel panel = new JPanel(new FlowLayout());
        panel.add(clickButton);
        panel.add(agreeCheckBox);

        add(panel, BorderLayout.CENTER);
        add(statusLabel, BorderLayout.SOUTH);
        setSize(400, 150);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Q1_DelegationEventModel());
    }
}
