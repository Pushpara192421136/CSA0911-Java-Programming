import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Q3_LayoutManagerDemo extends JFrame {
    private final JPanel demoPanel = new JPanel(new FlowLayout());

    public Q3_LayoutManagerDemo() {
        setTitle("Layout Manager Demo");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        demoPanel.add(new JButton("Button 1"));
        demoPanel.add(new JButton("Button 2"));
        demoPanel.add(new JButton("Button 3"));
        demoPanel.add(new JLabel("Label"));
        demoPanel.setBorder(BorderFactory.createTitledBorder("Demo Panel"));

        JRadioButton flowBtn = new JRadioButton("FlowLayout", true);
        JRadioButton borderBtn = new JRadioButton("BorderLayout");
        JRadioButton gridBtn = new JRadioButton("GridLayout");

        ButtonGroup group = new ButtonGroup();
        group.add(flowBtn);
        group.add(borderBtn);
        group.add(gridBtn);

        ItemListener layoutSwitcher = e -> {
            if (e.getStateChange() != ItemEvent.SELECTED) return;
            demoPanel.removeAll();
            if (flowBtn.isSelected()) {
                demoPanel.setLayout(new FlowLayout());
                addDemoComponents(false);
            } else if (borderBtn.isSelected()) {
                demoPanel.setLayout(new BorderLayout(5, 5));
                addDemoComponents(true);
            } else {
                demoPanel.setLayout(new GridLayout(2, 2, 5, 5));
                addDemoComponents(false);
            }
            demoPanel.revalidate();
            demoPanel.repaint();
        };

        flowBtn.addItemListener(layoutSwitcher);
        borderBtn.addItemListener(layoutSwitcher);
        gridBtn.addItemListener(layoutSwitcher);

        JPanel controlPanel = new JPanel(new FlowLayout());
        controlPanel.add(new JLabel("Select Layout:"));
        controlPanel.add(flowBtn);
        controlPanel.add(borderBtn);
        controlPanel.add(gridBtn);

        add(controlPanel, BorderLayout.NORTH);
        add(demoPanel, BorderLayout.CENTER);
        setSize(450, 250);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void addDemoComponents(boolean borderLayout) {
        if (borderLayout) {
            demoPanel.add(new JButton("North"), BorderLayout.NORTH);
            demoPanel.add(new JButton("South"), BorderLayout.SOUTH);
            demoPanel.add(new JButton("West"), BorderLayout.WEST);
            demoPanel.add(new JButton("East"), BorderLayout.EAST);
            demoPanel.add(new JLabel("Center"), BorderLayout.CENTER);
        } else {
            demoPanel.add(new JButton("Button 1"));
            demoPanel.add(new JButton("Button 2"));
            demoPanel.add(new JButton("Button 3"));
            demoPanel.add(new JLabel("Label"));
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Q3_LayoutManagerDemo());
    }
}
