import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * Question 8 — Employee Payroll System (JDBC)
 *
 * Single-file program covering:
 *   - Employee hierarchy with method overriding (calculateSalary)
 *   - Constructor overloading (with / without tax-deduction category)
 *   - Overloaded fetchEmployeeDetails(employeeId) and fetchEmployeeDetails(department)
 *   - JDBC ResultSet processing
 *   - InvalidSalaryDataException for null / negative salary fields
 *
 * ANALYSIS — SQLException mid-iteration (e.g. timeout after 500 rows)
 * -------------------------------------------------------------------------
 * Incremental List<Employee>: each row is mapped and added immediately.
 * If SQLException is thrown at row 501, those 500 objects already exist.
 * If that list is a field, returned early, or observed by another thread,
 * callers see a partial payroll snapshot. That is partial data exposure.
 *
 * Batch-then-return: rows are collected in a local list and returned only
 * after ResultSet.next() completes. On failure the exception propagates,
 * the local list is discarded, and the caller never receives incomplete data.
 * This program uses that all-or-nothing pattern.
 *
 * Resource strategy: try-with-resources on Connection, Statement,
 * PreparedStatement, and ResultSet. JDBC AutoCloseable closes them in
 * reverse order on both success and SQLException, so a timeout cannot
 * leak a ResultSet or Connection.
 *
 * Compile / run (H2 in-memory JDBC, no MySQL required):
 *   javac -cp h2-2.4.240.jar EmployeePayrollSystem.java
 *   java  -cp .;h2-2.4.240.jar EmployeePayrollSystem
 */
public class EmployeePayrollSystem {

    private static final String JDBC_URL = "jdbc:h2:mem:payroll;DB_CLOSE_DELAY=-1";
    private static final String JDBC_USER = "sa";
    private static final String JDBC_PASSWORD = "";

    public static void main(String[] args) {
        EmployeePayrollDao dao = new EmployeePayrollDao(JDBC_URL, JDBC_USER, JDBC_PASSWORD);

        try {
            dao.initializeSchemaAndSampleData();

            System.out.println("=== Fetch by employeeId (overloaded int) ===");
            printEmployees(dao.fetchEmployeeDetails(101));

            System.out.println("=== Fetch by department (overloaded String) ===");
            printEmployees(dao.fetchEmployeeDetails("IT"));

            System.out.println("=== Constructor overloading demo ===");
            PermanentEmployee withTax = new PermanentEmployee(
                    201, "Asha", "HR", 50000.0, 8000.0, "STANDARD");
            PermanentEmployee withoutTax = new PermanentEmployee(
                    202, "Rahul", "HR", 50000.0, 8000.0);
            System.out.println(withTax + " | net=" + withTax.calculateSalary());
            System.out.println(withoutTax + " | net=" + withoutTax.calculateSalary());

            System.out.println("=== InvalidSalaryDataException demo ===");
            try {
                dao.fetchEmployeeDetails(999);
            } catch (InvalidSalaryDataException ex) {
                System.out.println("Caught: " + ex.getMessage());
            }
        } catch (SQLException ex) {
            System.err.println("Database error: " + ex.getMessage());
        } catch (InvalidSalaryDataException ex) {
            System.err.println("Salary data error: " + ex.getMessage());
        }
    }

    private static void printEmployees(List<Employee> employees) {
        for (Employee employee : employees) {
            System.out.println(employee + " | net salary=" + employee.calculateSalary());
        }
        System.out.println();
    }
}

class InvalidSalaryDataException extends Exception {
    InvalidSalaryDataException(String message) {
        super(message);
    }
}

abstract class Employee {
    private final int employeeId;
    private final String name;
    private final String department;
    private final String taxDeductionCategory;

    Employee(int employeeId, String name, String department) {
        this(employeeId, name, department, null);
    }

    Employee(int employeeId, String name, String department, String taxDeductionCategory) {
        this.employeeId = employeeId;
        this.name = name;
        this.department = department;
        this.taxDeductionCategory = taxDeductionCategory;
    }

    int getEmployeeId() {
        return employeeId;
    }

    String getName() {
        return name;
    }

    String getDepartment() {
        return department;
    }

    String getTaxDeductionCategory() {
        return taxDeductionCategory;
    }

    boolean hasTaxDeductionCategory() {
        return taxDeductionCategory != null && !taxDeductionCategory.isBlank();
    }

    double taxRate() {
        if (!hasTaxDeductionCategory()) {
            return 0.0;
        }
        return switch (taxDeductionCategory.toUpperCase()) {
            case "STANDARD" -> 0.10;
            case "HIGH" -> 0.20;
            default -> 0.05;
        };
    }

    abstract double calculateSalary();

    @Override
    public String toString() {
        String tax = hasTaxDeductionCategory() ? taxDeductionCategory : "NONE";
        return getClass().getSimpleName()
                + "{id=" + employeeId
                + ", name='" + name + '\''
                + ", dept='" + department + '\''
                + ", tax=" + tax + '}';
    }
}

class PermanentEmployee extends Employee {
    private final double basicPay;
    private final double bonus;

    PermanentEmployee(int employeeId, String name, String department,
                      double basicPay, double bonus) {
        super(employeeId, name, department);
        this.basicPay = basicPay;
        this.bonus = bonus;
    }

    PermanentEmployee(int employeeId, String name, String department,
                      double basicPay, double bonus, String taxDeductionCategory) {
        super(employeeId, name, department, taxDeductionCategory);
        this.basicPay = basicPay;
        this.bonus = bonus;
    }

    @Override
    double calculateSalary() {
        double gross = basicPay + bonus;
        return gross - (gross * taxRate());
    }
}

class ContractEmployee extends Employee {
    private final double hourlyRate;
    private final int hoursWorked;

    ContractEmployee(int employeeId, String name, String department,
                     double hourlyRate, int hoursWorked) {
        super(employeeId, name, department);
        this.hourlyRate = hourlyRate;
        this.hoursWorked = hoursWorked;
    }

    ContractEmployee(int employeeId, String name, String department,
                     double hourlyRate, int hoursWorked, String taxDeductionCategory) {
        super(employeeId, name, department, taxDeductionCategory);
        this.hourlyRate = hourlyRate;
        this.hoursWorked = hoursWorked;
    }

    @Override
    double calculateSalary() {
        double gross = hourlyRate * hoursWorked;
        return gross - (gross * taxRate());
    }
}

class EmployeePayrollDao {
    private final String jdbcUrl;
    private final String user;
    private final String password;

    EmployeePayrollDao(String jdbcUrl, String user, String password) {
        this.jdbcUrl = jdbcUrl;
        this.user = user;
        this.password = password;
    }

    void initializeSchemaAndSampleData() throws SQLException {
        try (Connection connection = openConnection();
             Statement statement = connection.createStatement()) {
            statement.execute("""
                    CREATE TABLE employee (
                        employee_id INT PRIMARY KEY,
                        name VARCHAR(80) NOT NULL,
                        department VARCHAR(40) NOT NULL,
                        emp_type VARCHAR(20) NOT NULL,
                        tax_category VARCHAR(20),
                        basic_pay DOUBLE,
                        bonus DOUBLE,
                        hourly_rate DOUBLE,
                        hours_worked INT
                    )
                    """);
            statement.execute("""
                    INSERT INTO employee VALUES
                    (101, 'Meera', 'IT', 'PERMANENT', 'STANDARD', 60000, 12000, NULL, NULL),
                    (102, 'Kiran', 'IT', 'CONTRACT', NULL, NULL, NULL, 450, 160),
                    (103, 'Divya', 'Finance', 'PERMANENT', 'HIGH', 70000, 5000, NULL, NULL),
                    (104, 'Omar', 'IT', 'CONTRACT', 'STANDARD', NULL, NULL, 500, 140),
                    (999, 'Broken', 'IT', 'PERMANENT', NULL, -1000, 0, NULL, NULL)
                    """);
        }
    }

    List<Employee> fetchEmployeeDetails(int employeeId)
            throws SQLException, InvalidSalaryDataException {
        String sql = "SELECT * FROM employee WHERE employee_id = ?";
        try (Connection connection = openConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, employeeId);
            return readEmployees(statement);
        }
    }

    List<Employee> fetchEmployeeDetails(String department)
            throws SQLException, InvalidSalaryDataException {
        String sql = "SELECT * FROM employee WHERE department = ? AND employee_id <> 999";
        try (Connection connection = openConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, department);
            return readEmployees(statement);
        }
    }

    private List<Employee> readEmployees(PreparedStatement statement)
            throws SQLException, InvalidSalaryDataException {
        List<Employee> employees = new ArrayList<>();
        try (ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                employees.add(mapRow(resultSet));
            }
        }
        return employees;
    }

    private Employee mapRow(ResultSet resultSet) throws SQLException, InvalidSalaryDataException {
        int employeeId = resultSet.getInt("employee_id");
        String name = resultSet.getString("name");
        String department = resultSet.getString("department");
        String empType = resultSet.getString("emp_type");
        String taxCategory = resultSet.getString("tax_category");

        if ("PERMANENT".equalsIgnoreCase(empType)) {
            Double basicPay = nullableDouble(resultSet, "basic_pay");
            Double bonus = nullableDouble(resultSet, "bonus");
            validateSalaryField("basic_pay", basicPay);
            validateSalaryField("bonus", bonus);
            if (taxCategory == null) {
                return new PermanentEmployee(employeeId, name, department, basicPay, bonus);
            }
            return new PermanentEmployee(employeeId, name, department, basicPay, bonus, taxCategory);
        }

        if ("CONTRACT".equalsIgnoreCase(empType)) {
            Double hourlyRate = nullableDouble(resultSet, "hourly_rate");
            Integer hoursWorked = nullableInt(resultSet, "hours_worked");
            validateSalaryField("hourly_rate", hourlyRate);
            if (hoursWorked == null || hoursWorked < 0) {
                throw new InvalidSalaryDataException(
                        "hours_worked is null or negative for employeeId=" + employeeId);
            }
            if (taxCategory == null) {
                return new ContractEmployee(employeeId, name, department, hourlyRate, hoursWorked);
            }
            return new ContractEmployee(
                    employeeId, name, department, hourlyRate, hoursWorked, taxCategory);
        }

        throw new InvalidSalaryDataException("Unknown emp_type for employeeId=" + employeeId);
    }

    private static Double nullableDouble(ResultSet resultSet, String column) throws SQLException {
        double value = resultSet.getDouble(column);
        return resultSet.wasNull() ? null : value;
    }

    private static Integer nullableInt(ResultSet resultSet, String column) throws SQLException {
        int value = resultSet.getInt(column);
        return resultSet.wasNull() ? null : value;
    }

    private static void validateSalaryField(String field, Double value)
            throws InvalidSalaryDataException {
        if (value == null || value < 0) {
            throw new InvalidSalaryDataException(
                    "Salary field '" + field + "' is null or negative: " + value);
        }
    }

    private Connection openConnection() throws SQLException {
        return DriverManager.getConnection(jdbcUrl, user, password);
    }
}
