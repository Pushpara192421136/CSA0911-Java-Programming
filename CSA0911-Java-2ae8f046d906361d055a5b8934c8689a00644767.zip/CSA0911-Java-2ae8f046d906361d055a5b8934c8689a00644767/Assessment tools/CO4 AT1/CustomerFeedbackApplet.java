import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

/**
 * Q1 - Customer Feedback System (Applet-based GUI)
 *
 * Note: javax.swing.JApplet was removed in Java 11+. This class uses JPanel
 * with the same Applet lifecycle methods (init, start) so it runs on modern JDKs
 * while keeping the Applet-based GUI design required by the assignment.
 *
 * Layout managers used:
 * - BorderLayout  : main panel (header, form, results, buttons)
 * - GridLayout    : input form rows
 * - FlowLayout    : rating radio buttons and action buttons
 */
public class CustomerFeedbackApplet extends JPanel implements ActionListener {

    private JTextField nameField;
    private JTextField emailField;
    private JTextArea commentsArea;
    private ButtonGroup ratingGroup;
    private JRadioButton[] ratingButtons;
    private JTextArea resultArea;
    private JButton submitButton;
    private JButton clearButton;

    /** Applet-style initialisation — builds the GUI components. */
    public void init() {
        setLayout(new BorderLayout(10, 10));

        JPanel root = new JPanel(new BorderLayout(10, 10));
        root.setBorder(new EmptyBorder(12, 12, 12, 12));

        root.add(createHeaderPanel(), BorderLayout.NORTH);
        root.add(createFormPanel(), BorderLayout.CENTER);
        root.add(createResultPanel(), BorderLayout.SOUTH);

        add(root, BorderLayout.CENTER);
        add(createButtonPanel(), BorderLayout.SOUTH);
    }

    /** Applet-style start — called after init when the GUI is ready. */
    public void start() {
        nameField.requestFocus();
    }

    private JPanel createHeaderPanel() {
        JPanel header = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JLabel title = new JLabel("Customer Feedback System");
        title.setFont(new java.awt.Font("SansSerif", java.awt.Font.BOLD, 18));
        header.add(title);
        return header;
    }

    private JPanel createFormPanel() {
        JPanel form = new JPanel(new GridLayout(4, 2, 8, 8));
        form.setBorder(new TitledBorder("Enter Your Feedback"));

        nameField = new JTextField(20);
        emailField = new JTextField(20);
        commentsArea = new JTextArea(4, 20);
        commentsArea.setLineWrap(true);
        commentsArea.setWrapStyleWord(true);

        form.add(new JLabel("Customer Name:"));
        form.add(nameField);
        form.add(new JLabel("Email:"));
        form.add(emailField);
        form.add(new JLabel("Comments:"));
        form.add(new JScrollPane(commentsArea));
        form.add(new JLabel("Rating (1-5):"));
        form.add(createRatingPanel());

        return form;
    }

    private JPanel createRatingPanel() {
        JPanel ratingPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        ratingGroup = new ButtonGroup();
        ratingButtons = new JRadioButton[5];

        for (int i = 0; i < 5; i++) {
            ratingButtons[i] = new JRadioButton(String.valueOf(i + 1));
            ratingGroup.add(ratingButtons[i]);
            ratingPanel.add(ratingButtons[i]);
        }

        ratingButtons[4].setSelected(true);
        return ratingPanel;
    }

    private JPanel createResultPanel() {
        JPanel resultPanel = new JPanel(new BorderLayout());
        resultPanel.setBorder(new TitledBorder("Feedback Summary"));

        resultArea = new JTextArea(6, 40);
        resultArea.setEditable(false);
        resultArea.setLineWrap(true);
        resultArea.setWrapStyleWord(true);
        resultArea.setText("Submitted feedback will appear here.");

        resultPanel.add(new JScrollPane(resultArea), BorderLayout.CENTER);
        return resultPanel;
    }

    private JPanel createButtonPanel() {
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 8));

        submitButton = new JButton("Submit Feedback");
        clearButton = new JButton("Clear");

        submitButton.addActionListener(this);
        clearButton.addActionListener(this);

        buttonPanel.add(submitButton);
        buttonPanel.add(clearButton);
        return buttonPanel;
    }

    @Override
    public void actionPerformed(ActionEvent event) {
        Object source = event.getSource();

        if (source == submitButton) {
            handleSubmit();
        } else if (source == clearButton) {
            handleClear();
        }
    }

    private void handleSubmit() {
        String name = nameField.getText().trim();
        String email = emailField.getText().trim();
        String comments = commentsArea.getText().trim();
        int rating = getSelectedRating();

        if (!validateInput(name, email, comments, rating)) {
            return;
        }

        resultArea.setText(buildSummary(name, email, comments, rating));
    }

    private boolean validateInput(String name, String email, String comments, int rating) {
        if (name.isEmpty()) {
            showError("Please enter your name.");
            nameField.requestFocus();
            return false;
        }

        if (email.isEmpty()) {
            showError("Please enter your email address.");
            emailField.requestFocus();
            return false;
        }

        if (!email.contains("@") || !email.contains(".")) {
            showError("Please enter a valid email address.");
            emailField.requestFocus();
            return false;
        }

        if (comments.isEmpty()) {
            showError("Please enter your comments.");
            commentsArea.requestFocus();
            return false;
        }

        if (rating < 1 || rating > 5) {
            showError("Please select a rating between 1 and 5.");
            return false;
        }

        return true;
    }

    private int getSelectedRating() {
        for (int i = 0; i < ratingButtons.length; i++) {
            if (ratingButtons[i].isSelected()) {
                return i + 1;
            }
        }
        return -1;
    }

    private String buildSummary(String name, String email, String comments, int rating) {
        StringBuilder summary = new StringBuilder();
        summary.append("Thank you for your feedback!\n\n");
        summary.append("Name   : ").append(name).append('\n');
        summary.append("Email  : ").append(email).append('\n');
        summary.append("Rating : ").append(rating).append(" / 5\n");
        summary.append("Comments:\n").append(comments).append('\n');
        summary.append("\nStatus : Feedback recorded successfully.");
        return summary.toString();
    }

    private void handleClear() {
        nameField.setText("");
        emailField.setText("");
        commentsArea.setText("");
        ratingButtons[4].setSelected(true);
        resultArea.setText("Submitted feedback will appear here.");
        nameField.requestFocus();
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog((Component) getTopLevelAncestor(), message,
                "Validation Error", JOptionPane.ERROR_MESSAGE);
    }

    /** Standalone launcher — modern browsers no longer support Java Applets. */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Customer Feedback System");
            CustomerFeedbackApplet applet = new CustomerFeedbackApplet();
            applet.init();
            applet.start();

            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.getContentPane().add(applet);
            frame.setSize(620, 520);
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }
}
