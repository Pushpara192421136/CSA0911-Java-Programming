import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

// ==========================================
// CUSTOM EXCEPTION CLASSES
// ==========================================
class SeatAlreadyBookedException extends Exception {
    public SeatAlreadyBookedException(String message) {
        super(message);
    }
}

class NoSeatSelectedException extends Exception {
    public NoSeatSelectedException(String message) {
        super(message);
    }
}

class InvalidInputException extends Exception {
    public InvalidInputException(String message) {
        super(message);
    }
}

// ==========================================
// DATA MODELS
// ==========================================
class Booking {
    private String bookingId;
    private String customerName;
    private String phone;
    private String showTime;
    private String seatId;
    private double price;

    public Booking(String bookingId, String customerName, String phone, String showTime, String seatId, double price) {
        this.bookingId = bookingId;
        this.customerName = customerName;
        this.phone = phone;
        this.showTime = showTime;
        this.seatId = seatId;
        this.price = price;
    }

    public String getBookingId() { return bookingId; }
    public String getCustomerName() { return customerName; }
    public String getPhone() { return phone; }
    public String getShowTime() { return showTime; }
    public String getSeatId() { return seatId; }
    public double getPrice() { return price; }
}

// ==========================================
// MAIN MULTI-WINDOW APPLICATION
// ==========================================
public class TicketBookingSystem extends JFrame {

    // Colors & Styling Constants
    private static final Color COLOR_AVAILABLE = new Color(46, 204, 113); // Green
    private static final Color COLOR_SELECTED = new Color(52, 152, 219);  // Blue
    private static final Color COLOR_BOOKED = new Color(231, 76, 60);    // Red
    private static final Color COLOR_BG = new Color(245, 247, 250);

    // Data structures
    private Map<String, Boolean> seatStatusMap = new HashMap<>(); // seatId -> isBooked
    private Map<String, Booking> bookingsMap = new HashMap<>();   // bookingId -> Booking
    private String selectedSeatId = null;
    private JButton selectedSeatButton = null;
    private int bookingCounter = 1001;

    // Swing Components
    private JPanel seatGridPanel;
    private JComboBox<String> showTimeCombo;
    private JTextField nameField;
    private JTextField phoneField;
    private JLabel selectedSeatLabel;
    private JLabel statusLabel;

    public TicketBookingSystem() {
        setTitle("Cinema Ticket Booking System");
        setSize(850, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));
        getContentPane().setBackground(COLOR_BG);

        // Initialize 5x5 seats (A1 to E5)
        initializeSeatData();

        // Build UI Sections
        setJMenuBar(createMenuBar());
        add(createHeaderPanel(), BorderLayout.NORTH);
        add(createMainContentPanel(), BorderLayout.CENTER);
        add(createFooterPanel(), BorderLayout.SOUTH);
    }

    // ------------------------------------------
    // SEAT DATA INITIALIZATION
    // ------------------------------------------
    private void initializeSeatData() {
        char[] rows = {'A', 'B', 'C', 'D', 'E'};
        for (char r : rows) {
            for (int c = 1; c <= 5; c++) {
                seatStatusMap.put("" + r + c, false);
            }
        }
    }

    // ------------------------------------------
    // MENU BAR CREATION
    // ------------------------------------------
    private JMenuBar createMenuBar() {
        JMenuBar menuBar = new JMenuBar();

        JMenu menuNav = new JMenu("Navigation");
        JMenuItem itemBook = new JMenuItem("Book Seat");
        JMenuItem itemCancel = new JMenuItem("Cancel Booking Window");
        JMenuItem itemView = new JMenuItem("View All Bookings Window");
        JMenuItem itemExit = new JMenuItem("Exit");

        itemNavActions(itemBook, itemCancel, itemView, itemExit);

        menuNav.add(itemBook);
        menuNav.add(itemCancel);
        menuNav.add(itemView);
        menuNav.addSeparator();
        menuNav.add(itemExit);

        JMenu menuAnalysis = new JMenu("Analysis & UX");
        JMenuItem itemUX = new JMenuItem("UX & Responsiveness Analysis");
        itemUX.addActionListener(e -> openUXAnalysisWindow());
        menuAnalysis.add(itemUX);

        menuBar.add(menuNav);
        menuBar.add(menuAnalysis);
        return menuBar;
    }

    private void itemNavActions(JMenuItem itemBook, JMenuItem itemCancel, JMenuItem itemView, JMenuItem itemExit) {
        itemBook.addActionListener(e -> statusLabel.setText("Status: Select a seat to book."));
        itemCancel.addActionListener(e -> openCancellationWindow());
        itemView.addActionListener(e -> openViewBookingsWindow());
        itemExit.addActionListener(e -> System.exit(0));
    }

    // ------------------------------------------
    // HEADER PANEL
    // ------------------------------------------
    private JPanel createHeaderPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 5));
        panel.setBackground(new Color(41, 128, 185));
        panel.setBorder(BorderFactory.createEmptyBorder(12, 15, 12, 15));

        JLabel titleLabel = new JLabel("🎬 MULTI-WINDOW TICKET BOOKING SYSTEM", SwingConstants.CENTER);
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 20));
        titleLabel.setForeground(Color.WHITE);

        JPanel comboPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        comboPanel.setOpaque(false);
        JLabel showLabel = new JLabel("Select Show Time: ");
        showLabel.setForeground(Color.WHITE);
        showLabel.setFont(new Font("SansSerif", Font.BOLD, 12));

        String[] showTimes = {"10:00 AM - Morning Show", "02:30 PM - Matinee Show", "06:45 PM - Evening Show", "09:30 PM - Night Show"};
        showTimeCombo = new JComboBox<>(showTimes);

        comboPanel.add(showLabel);
        comboPanel.add(showTimeCombo);

        panel.add(titleLabel, BorderLayout.CENTER);
        panel.add(comboPanel, BorderLayout.SOUTH);
        return panel;
    }

    // ------------------------------------------
    // MAIN CONTENT PANEL (SEATS GRID & CUSTOMER FORM)
    // ------------------------------------------
    private JPanel createMainContentPanel() {
        JPanel mainPanel = new JPanel(new GridLayout(1, 2, 15, 15));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        mainPanel.setOpaque(false);

        // Left Component: Seat Grid
        JPanel seatSelectionContainer = new JPanel(new BorderLayout(10, 10));
        seatSelectionContainer.setBorder(BorderFactory.createTitledBorder("Step 1: Select Your Seat"));
        seatSelectionContainer.setBackground(Color.WHITE);

        // Screen Banner
        JLabel screenLabel = new JLabel("--- SCREEN THIS WAY ---", SwingConstants.CENTER);
        screenLabel.setOpaque(true);
        screenLabel.setBackground(new Color(220, 224, 230));
        screenLabel.setFont(new Font("SansSerif", Font.BOLD, 12));
        seatSelectionContainer.add(screenLabel, BorderLayout.NORTH);

        // Grid Panel (5x5)
        seatGridPanel = new JPanel(new GridLayout(5, 5, 8, 8));
        seatGridPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        seatGridPanel.setBackground(Color.WHITE);
        refreshSeatGrid();
        seatSelectionContainer.add(seatGridPanel, BorderLayout.CENTER);

        // Legend
        JPanel legendPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        legendPanel.setBackground(Color.WHITE);
        legendPanel.add(createLegendItem("Available", COLOR_AVAILABLE));
        legendPanel.add(createLegendItem("Selected", COLOR_SELECTED));
        legendPanel.add(createLegendItem("Booked", COLOR_BOOKED));
        seatSelectionContainer.add(legendPanel, BorderLayout.SOUTH);

        // Right Component: Customer Info Form & Actions
        JPanel formContainer = new JPanel(new GridBagLayout());
        formContainer.setBorder(BorderFactory.createTitledBorder("Step 2: Customer Details & Booking"));
        formContainer.setBackground(Color.WHITE);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Selected Seat Display
        gbc.gridx = 0; gbc.gridy = 0;
        formContainer.add(new JLabel("Selected Seat:"), gbc);
        gbc.gridx = 1;
        selectedSeatLabel = new JLabel("None", SwingConstants.LEFT);
        selectedSeatLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
        selectedSeatLabel.setForeground(COLOR_SELECTED);
        formContainer.add(selectedSeatLabel, gbc);

        // Ticket Price
        gbc.gridx = 0; gbc.gridy = 1;
        formContainer.add(new JLabel("Price per Ticket:"), gbc);
        gbc.gridx = 1;
        JLabel priceLabel = new JLabel("$12.50");
        priceLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
        formContainer.add(priceLabel, gbc);

        // Name Input
        gbc.gridx = 0; gbc.gridy = 2;
        formContainer.add(new JLabel("Customer Name:"), gbc);
        gbc.gridx = 1;
        nameField = new JTextField(15);
        formContainer.add(nameField, gbc);

        // Phone Input
        gbc.gridx = 0; gbc.gridy = 3;
        formContainer.add(new JLabel("Phone Number:"), gbc);
        gbc.gridx = 1;
        phoneField = new JTextField(15);
        formContainer.add(phoneField, gbc);

        // Action Buttons
        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2;
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        btnPanel.setOpaque(false);

        JButton proceedBtn = new JButton("Proceed to Confirmation Window");
        proceedBtn.setBackground(COLOR_SELECTED);
        proceedBtn.setForeground(Color.WHITE);
        proceedBtn.setFont(new Font("SansSerif", Font.BOLD, 12));
        proceedBtn.addActionListener(e -> handleProceedToConfirmation());

        JButton clearBtn = new JButton("Clear Selection");
        clearBtn.addActionListener(e -> clearSelection());

        btnPanel.add(proceedBtn);
        btnPanel.add(clearBtn);
        formContainer.add(btnPanel, gbc);

        // Window Shortcuts Panel
        gbc.gridy = 5;
        JPanel quickNavPanel = new JPanel(new GridLayout(2, 1, 5, 5));
        quickNavPanel.setBorder(BorderFactory.createTitledBorder("Quick Navigation Windows"));
        quickNavPanel.setOpaque(false);

        JButton openCancelBtn = new JButton("Open Cancellation Window");
        openCancelBtn.addActionListener(e -> openCancellationWindow());

        JButton openViewBtn = new JButton("Open View All Bookings Window");
        openViewBtn.addActionListener(e -> openViewBookingsWindow());

        quickNavPanel.add(openCancelBtn);
        quickNavPanel.add(openViewBtn);

        formContainer.add(quickNavPanel, gbc);

        mainPanel.add(seatSelectionContainer);
        mainPanel.add(formContainer);
        return mainPanel;
    }

    // Helper to render seat legend badge
    private JPanel createLegendItem(String text, Color color) {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
        p.setOpaque(false);
        JLabel box = new JLabel("   ");
        box.setOpaque(true);
        box.setBackground(color);
        box.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        p.add(box);
        p.add(new JLabel(text));
        return p;
    }

    // Refresh seat grid buttons based on current status
    private void refreshSeatGrid() {
        seatGridPanel.removeAll();
        char[] rows = {'A', 'B', 'C', 'D', 'E'};

        for (char r : rows) {
            for (int c = 1; c <= 5; c++) {
                String seatId = "" + r + c;
                JButton seatBtn = new JButton(seatId);
                seatBtn.setFont(new Font("SansSerif", Font.BOLD, 11));
                seatBtn.setFocusPainted(false);

                boolean isBooked = seatStatusMap.getOrDefault(seatId, false);
                if (isBooked) {
                    seatBtn.setBackground(COLOR_BOOKED);
                    seatBtn.setForeground(Color.WHITE);
                    seatBtn.setToolTipText("Seat " + seatId + " is BOOKED");
                } else if (seatId.equals(selectedSeatId)) {
                    seatBtn.setBackground(COLOR_SELECTED);
                    seatBtn.setForeground(Color.WHITE);
                    seatBtn.setToolTipText("Seat " + seatId + " is SELECTED");
                } else {
                    seatBtn.setBackground(COLOR_AVAILABLE);
                    seatBtn.setForeground(Color.WHITE);
                    seatBtn.setToolTipText("Seat " + seatId + " is AVAILABLE");
                }

                seatBtn.addActionListener(new SeatButtonListener(seatId, seatBtn));
                seatGridPanel.add(seatBtn);
            }
        }
        seatGridPanel.revalidate();
        seatGridPanel.repaint();
    }

    // Event listener for Seat Buttons
    private class SeatButtonListener implements ActionListener {
        private String seatId;
        private JButton button;

        public SeatButtonListener(String seatId, JButton button) {
            this.seatId = seatId;
            this.button = button;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                if (seatStatusMap.getOrDefault(seatId, false)) {
                    throw new SeatAlreadyBookedException("Seat " + seatId + " is already booked! Please select an available seat.");
                }

                // Deselect previous seat if any
                selectedSeatId = seatId;
                selectedSeatButton = button;
                selectedSeatLabel.setText(seatId);
                statusLabel.setText("Status: Selected seat " + seatId + ". Ready to proceed.");

                refreshSeatGrid();
            } catch (SeatAlreadyBookedException ex) {
                JOptionPane.showMessageDialog(TicketBookingSystem.this, ex.getMessage(), "Seat Unavailable", JOptionPane.WARNING_MESSAGE);
            }
        }
    }

    // Clear current selection
    private void clearSelection() {
        selectedSeatId = null;
        selectedSeatButton = null;
        selectedSeatLabel.setText("None");
        statusLabel.setText("Status: Selection cleared.");
        refreshSeatGrid();
    }

    // ------------------------------------------
    // INPUT VALIDATION & PROCEED TO CONFIRMATION WINDOW
    // ------------------------------------------
    private void handleProceedToConfirmation() {
        try {
            // Validate Seat Selection
            if (selectedSeatId == null) {
                throw new NoSeatSelectedException("Please click on an available seat from the grid before proceeding!");
            }

            // Validate Customer Name
            String name = nameField.getText().trim();
            if (name.isEmpty()) {
                throw new InvalidInputException("Customer Name cannot be empty!");
            }
            if (!name.matches("^[a-zA-Z\\s]+$")) {
                throw new InvalidInputException("Customer Name should contain only letters and spaces!");
            }

            // Validate Phone Number
            String phone = phoneField.getText().trim();
            if (phone.isEmpty()) {
                throw new InvalidInputException("Phone Number cannot be empty!");
            }
            if (!phone.matches("^\\d{10}$")) {
                throw new InvalidInputException("Phone Number must contain exactly 10 numerical digits!");
            }

            // If validation passes, open Booking Confirmation Window (JDialog)
            openConfirmationWindow(name, phone, (String) showTimeCombo.getSelectedItem(), selectedSeatId, 12.50);

        } catch (NoSeatSelectedException | InvalidInputException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Input Validation Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // ------------------------------------------
    // WINDOW 2: BOOKING CONFIRMATION DIALOG (JDialog)
    // ------------------------------------------
    private void openConfirmationWindow(String name, String phone, String showTime, String seatId, double price) {
        JDialog confirmDialog = new JDialog(this, "Window 2: Booking Confirmation", true);
        confirmDialog.setSize(420, 320);
        confirmDialog.setLocationRelativeTo(this);
        confirmDialog.setLayout(new BorderLayout(10, 10));

        JPanel content = new JPanel(new GridLayout(6, 2, 8, 8));
        content.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        content.add(new JLabel("Customer Name:"));
        content.add(new JLabel(name));

        content.add(new JLabel("Phone Number:"));
        content.add(new JLabel(phone));

        content.add(new JLabel("Show Time:"));
        content.add(new JLabel(showTime));

        content.add(new JLabel("Allocated Seat:"));
        JLabel seatLbl = new JLabel(seatId);
        seatLbl.setFont(new Font("SansSerif", Font.BOLD, 14));
        seatLbl.setForeground(COLOR_SELECTED);
        content.add(seatLbl);

        content.add(new JLabel("Total Price:"));
        content.add(new JLabel("$" + String.format("%.2f", price)));

        content.add(new JLabel("Status:"));
        content.add(new JLabel("Pending Confirmation"));

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        JButton confirmBtn = new JButton("Confirm Booking");
        confirmBtn.setBackground(COLOR_AVAILABLE);
        confirmBtn.setForeground(Color.WHITE);

        JButton cancelBtn = new JButton("Back / Cancel");

        confirmBtn.addActionListener(e -> {
            // Generate Booking ID
            String bId = "BK" + (bookingCounter++);
            Booking newBooking = new Booking(bId, name, phone, showTime, seatId, price);

            // Update state
            seatStatusMap.put(seatId, true);
            bookingsMap.put(bId, newBooking);

            // Reset UI selection
            selectedSeatId = null;
            selectedSeatLabel.setText("None");
            nameField.setText("");
            phoneField.setText("");
            refreshSeatGrid();

            confirmDialog.dispose();

            // Success Dialog
            JOptionPane.showMessageDialog(this,
                    "🎉 Booking Confirmed Successfully!\n\nBooking ID: " + bId +
                            "\nCustomer: " + name +
                            "\nSeat: " + seatId +
                            "\nShow: " + showTime,
                    "Booking Successful",
                    JOptionPane.INFORMATION_MESSAGE);

            statusLabel.setText("Status: Booking " + bId + " confirmed for Seat " + seatId + ".");
        });

        cancelBtn.addActionListener(e -> confirmDialog.dispose());

        btnPanel.add(confirmBtn);
        btnPanel.add(cancelBtn);

        confirmDialog.add(content, BorderLayout.CENTER);
        confirmDialog.add(btnPanel, BorderLayout.SOUTH);
        confirmDialog.setVisible(true);
    }

    // ------------------------------------------
    // WINDOW 3: CANCELLATION WINDOW (JDialog)
    // ------------------------------------------
    private void openCancellationWindow() {
        JDialog cancelDialog = new JDialog(this, "Window 3: Ticket Cancellation", true);
        cancelDialog.setSize(450, 260);
        cancelDialog.setLocationRelativeTo(this);
        cancelDialog.setLayout(new BorderLayout(10, 10));

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(new JLabel("Enter Booking ID to Cancel:"), gbc);

        gbc.gridx = 1;
        JTextField inputIdField = new JTextField(12);
        panel.add(inputIdField, gbc);

        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 2;
        JLabel infoLabel = new JLabel("e.g. BK1001", SwingConstants.CENTER);
        infoLabel.setForeground(Color.GRAY);
        panel.add(infoLabel, gbc);

        gbc.gridy = 2;
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        JButton submitCancelBtn = new JButton("Cancel Ticket");
        submitCancelBtn.setBackground(COLOR_BOOKED);
        submitCancelBtn.setForeground(Color.WHITE);

        JButton closeBtn = new JButton("Close");

        submitCancelBtn.addActionListener(e -> {
            try {
                String bookingId = inputIdField.getText().trim().toUpperCase();
                if (bookingId.isEmpty()) {
                    throw new InvalidInputException("Please enter a valid Booking ID!");
                }

                if (!bookingsMap.containsKey(bookingId)) {
                    throw new InvalidInputException("Booking ID '" + bookingId + "' not found in the system!");
                }

                Booking b = bookingsMap.get(bookingId);

                int confirm = JOptionPane.showConfirmDialog(cancelDialog,
                        "Are you sure you want to cancel booking " + bookingId + " for Seat " + b.getSeatId() + "?",
                        "Confirm Cancellation", JOptionPane.YES_NO_OPTION);

                if (confirm == JOptionPane.YES_OPTION) {
                    // Free up seat
                    seatStatusMap.put(b.getSeatId(), false);
                    bookingsMap.remove(bookingId);

                    refreshSeatGrid();
                    cancelDialog.dispose();

                    JOptionPane.showMessageDialog(this,
                            "Ticket " + bookingId + " cancelled successfully. Seat " + b.getSeatId() + " is now AVAILABLE.",
                            "Cancellation Successful", JOptionPane.INFORMATION_MESSAGE);

                    statusLabel.setText("Status: Booking " + bookingId + " cancelled. Seat " + b.getSeatId() + " released.");
                }
            } catch (InvalidInputException ex) {
                JOptionPane.showMessageDialog(cancelDialog, ex.getMessage(), "Cancellation Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        closeBtn.addActionListener(e -> cancelDialog.dispose());

        btnPanel.add(submitCancelBtn);
        btnPanel.add(closeBtn);
        panel.add(btnPanel, gbc);

        cancelDialog.add(panel, BorderLayout.CENTER);
        cancelDialog.setVisible(true);
    }

    // ------------------------------------------
    // WINDOW 4: VIEW ALL BOOKINGS WINDOW (JDialog)
    // ------------------------------------------
    private void openViewBookingsWindow() {
        JDialog viewDialog = new JDialog(this, "Window 4: Active Bookings List", true);
        viewDialog.setSize(600, 350);
        viewDialog.setLocationRelativeTo(this);
        viewDialog.setLayout(new BorderLayout(10, 10));

        String[] columns = {"Booking ID", "Customer Name", "Phone", "Seat", "Show Time", "Price"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);

        for (Booking b : bookingsMap.values()) {
            Object[] row = {
                    b.getBookingId(),
                    b.getCustomerName(),
                    b.getPhone(),
                    b.getSeatId(),
                    b.getShowTime(),
                    "$" + String.format("%.2f", b.getPrice())
            };
            model.addRow(row);
        }

        JTable table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        viewDialog.add(scrollPane, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JLabel totalLabel = new JLabel("Total Active Bookings: " + bookingsMap.size() + "  ");
        totalLabel.setFont(new Font("SansSerif", Font.BOLD, 12));
        JButton closeBtn = new JButton("Close");
        closeBtn.addActionListener(e -> viewDialog.dispose());

        bottomPanel.add(totalLabel);
        bottomPanel.add(closeBtn);
        viewDialog.add(bottomPanel, BorderLayout.SOUTH);

        viewDialog.setVisible(true);
    }

    // ------------------------------------------
    // WINDOW 5: UX & RESPONSIVENESS ANALYSIS WINDOW
    // ------------------------------------------
    private void openUXAnalysisWindow() {
        JDialog uxDialog = new JDialog(this, "UX Analysis & Real-time Interaction Improvements", true);
        uxDialog.setSize(650, 480);
        uxDialog.setLocationRelativeTo(this);
        uxDialog.setLayout(new BorderLayout(10, 10));

        JTextArea textArea = new JTextArea();
        textArea.setEditable(false);
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        textArea.setMargin(new Insets(10, 10, 10, 10));

        String analysisText =
                "=========================================================================\n" +
                "  USER EXPERIENCE (UX) & REAL-TIME RESPONSIVENESS ANALYSIS               \n" +
                "=========================================================================\n\n" +
                "1. CURRENT UX DESIGN HIGHLIGHTS:\n" +
                "   - Visual Seat Map: Color-coded grid (Green=Available, Blue=Selected, Red=Booked)\n" +
                "     provides immediate visual feedback without manual seat typing.\n" +
                "   - Multi-Window Workflow: Clean separation between Seat Selection (Main),\n" +
                "     Confirmation Dialog (Modal), Cancellation Window, and View Bookings Window.\n" +
                "   - Instant Input Validation: Validates customer name and 10-digit phone number\n" +
                "     with custom exception handling before opening confirmation.\n\n" +
                "2. IDENTIFIED AREAS FOR IMPROVING REAL-TIME INTERACTION & RESPONSIVENESS:\n" +
                "   - Concurrent User Synchronization:\n" +
                "     In multi-user production environments, seat locking via WebSockets or SSE\n" +
                "     (Server-Sent Events) is needed so seats selected by User A update instantly\n" +
                "     on User B's screen in real time.\n" +
                "   - Non-Blocking Background Operations (SwingWorker):\n" +
                "     Database writes and payment gateway calls should be executed asynchronously\n" +
                "     using SwingWorker to keep the Event Dispatch Thread (EDT) responsive.\n" +
                "   - Temporary Seat Reservation Timer:\n" +
                "     Implement a countdown timer (e.g., 5 minutes) when a seat is selected to\n" +
                "     prevent infinite holding of seats during checkout.\n" +
                "   - Keyboard Accessibility & Screen Readers:\n" +
                "     Adding keyboard shortcuts (Mnemonics & Accelerators) and AccessibleContext\n" +
                "     tags improves inclusivity for visually impaired users.\n" +
                "=========================================================================\n";

        textArea.setText(analysisText);
        JScrollPane scrollPane = new JScrollPane(textArea);

        JButton closeBtn = new JButton("Close Analysis Window");
        closeBtn.addActionListener(e -> uxDialog.dispose());
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        btnPanel.add(closeBtn);

        uxDialog.add(scrollPane, BorderLayout.CENTER);
        uxDialog.add(btnPanel, BorderLayout.SOUTH);
        uxDialog.setVisible(true);
    }

    // ------------------------------------------
    // FOOTER STATUS BAR
    // ------------------------------------------
    private JPanel createFooterPanel() {
        JPanel footer = new JPanel(new BorderLayout());
        footer.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1, 0, 0, 0, Color.LIGHT_GRAY),
                BorderFactory.createEmptyBorder(6, 12, 6, 12)
        ));
        footer.setBackground(new Color(236, 240, 241));

        statusLabel = new JLabel("Status: System Ready. Select an available green seat to begin.");
        statusLabel.setFont(new Font("SansSerif", Font.PLAIN, 12));

        footer.add(statusLabel, BorderLayout.WEST);
        return footer;
    }

    // ------------------------------------------
    // MAIN METHOD WITH SAMPLE BOOKING SCENARIOS
    // ------------------------------------------
    public static void main(String[] args) {
        // Run GUI on Event Dispatch Thread (EDT)
        SwingUtilities.invokeLater(() -> {
            try {
                // Set Native Look and Feel
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) {}

            TicketBookingSystem app = new TicketBookingSystem();
            app.setVisible(true);

            // Pre-load sample booking scenarios to demonstrate functionality out-of-the-box
            app.seatStatusMap.put("A1", true);
            app.bookingsMap.put("BK1000", new Booking("BK1000", "Alice Smith", "9876543210", "10:00 AM - Morning Show", "A1", 12.50));

            app.seatStatusMap.put("C3", true);
            app.bookingsMap.put("BK1001", new Booking("BK1001", "Bob Jones", "9123456789", "02:30 PM - Matinee Show", "C3", 12.50));

            app.refreshSeatGrid();
        });
    }
}
