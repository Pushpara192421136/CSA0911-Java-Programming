import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Q3_FileCopy {
    public static void main(String[] args) {
        String sourceFile = "source.txt";
        String destinationFile = "destination.txt";

        try {
            BufferedWriter setup = new BufferedWriter(new FileWriter(sourceFile));
            setup.write("This is the source file.\n");
            setup.write("Its content will be copied to the destination file.\n");
            setup.write("Copy is done using BufferedReader and BufferedWriter.\n");
            setup.close();

            BufferedReader reader = new BufferedReader(new FileReader(sourceFile));
            BufferedWriter writer = new BufferedWriter(new FileWriter(destinationFile));

            String line;
            while ((line = reader.readLine()) != null) {
                writer.write(line);
                writer.newLine();
            }

            reader.close();
            writer.close();

            System.out.println("Content copied from " + sourceFile + " to " + destinationFile + ".");
        } catch (IOException e) {
            System.out.println("An error occurred while copying the file.");
            e.printStackTrace();
        }
    }
}
