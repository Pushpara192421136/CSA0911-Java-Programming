import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Q1_FileCreation {
    public static void main(String[] args) {
        File file = new File("student.txt");

        try {
            if (file.createNewFile()) {
                System.out.println("File created: " + file.getName());
            } else {
                System.out.println("File already exists: " + file.getName());
            }

            FileWriter writer = new FileWriter(file);
            writer.write("Name: Anish\n");
            writer.write("Course: CSA09 Java Programming\n");
            writer.write("Topic: File Creation and Writing Data\n");
            writer.close();

            System.out.println("Data written to " + file.getName() + " successfully.");
        } catch (IOException e) {
            System.out.println("An error occurred while creating or writing the file.");
            e.printStackTrace();
        }
    }
}
