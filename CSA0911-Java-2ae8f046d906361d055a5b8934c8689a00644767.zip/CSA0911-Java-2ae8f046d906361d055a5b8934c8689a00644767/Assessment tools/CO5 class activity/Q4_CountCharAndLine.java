import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Q4_CountCharAndLine {
    public static void main(String[] args) {
        String fileName = "source.txt";

        try {
            FileWriter setup = new FileWriter(fileName);
            setup.write("Java file handling is useful.\n");
            setup.write("This program counts characters and lines.\n");
            setup.write("Each line in this file is counted.\n");
            setup.close();

            BufferedReader reader = new BufferedReader(new FileReader(fileName));
            int lineCount = 0;
            int charCount = 0;
            String line;

            while ((line = reader.readLine()) != null) {
                lineCount++;
                charCount += line.length();
            }
            reader.close();

            System.out.println("Source file: " + fileName);
            System.out.println("Number of lines: " + lineCount);
            System.out.println("Number of characters: " + charCount);
        } catch (IOException e) {
            System.out.println("An error occurred while reading the file.");
            e.printStackTrace();
        }
    }
}
