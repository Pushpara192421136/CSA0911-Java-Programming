import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Q5_DeleteAndCreate {
    public static void main(String[] args) {
        File file = new File("temp.txt");

        try {
            if (!file.exists()) {
                file.createNewFile();
                FileWriter writer = new FileWriter(file);
                writer.write("This is a sample file that will be deleted and created again.\n");
                writer.close();
                System.out.println("Sample file created for demonstration: " + file.getName());
            }

            if (file.exists()) {
                if (file.delete()) {
                    System.out.println("File deleted: " + file.getName());
                } else {
                    System.out.println("Failed to delete the file.");
                    return;
                }
            } else {
                System.out.println("File does not exist.");
            }

            if (file.createNewFile()) {
                FileWriter writer = new FileWriter(file);
                writer.write("New file created after deletion.\n");
                writer.close();
                System.out.println("File created again: " + file.getName());
            } else {
                System.out.println("Unable to create the file again.");
            }
        } catch (IOException e) {
            System.out.println("An error occurred while deleting or creating the file.");
            e.printStackTrace();
        }
    }
}
