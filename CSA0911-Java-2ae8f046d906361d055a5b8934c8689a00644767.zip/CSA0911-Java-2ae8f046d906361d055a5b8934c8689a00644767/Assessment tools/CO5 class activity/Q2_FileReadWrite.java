import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Q2_FileReadWrite {
    public static void main(String[] args) {
        String fileName = "data.txt";

        try {
            FileWriter writer = new FileWriter(fileName);
            writer.write("Welcome to Java File Handling.\n");
            writer.write("This program uses FileWriter to write data.\n");
            writer.write("Then FileReader is used to read and display the content.\n");
            writer.close();
            System.out.println("Data written to " + fileName + " using FileWriter.\n");

            System.out.println("Content of " + fileName + ":");
            FileReader reader = new FileReader(fileName);
            int ch;
            while ((ch = reader.read()) != -1) {
                System.out.print((char) ch);
            }
            reader.close();
        } catch (IOException e) {
            System.out.println("An error occurred while reading or writing the file.");
            e.printStackTrace();
        }
    }
}
