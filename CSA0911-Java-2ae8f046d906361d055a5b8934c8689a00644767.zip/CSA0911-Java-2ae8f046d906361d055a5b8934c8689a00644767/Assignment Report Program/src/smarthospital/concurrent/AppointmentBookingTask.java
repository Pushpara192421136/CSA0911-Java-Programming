package smarthospital.concurrent;

import smarthospital.exception.DoctorFullyBookedException;
import smarthospital.exception.DuplicateAppointmentException;
import smarthospital.exception.InvalidPatientIdException;
import smarthospital.service.HospitalService;

/**
 * Concurrent booking worker with high thread priority. Uses synchronized service methods.
 */
public class AppointmentBookingTask extends Thread {
    private final HospitalService service;
    private final String patientId;
    private final String doctorId;
    private final String preferredSlot;
    private volatile String outcome;

    public AppointmentBookingTask(HospitalService service, String patientId, String doctorId, String preferredSlot) {
        super("booking-" + patientId);
        this.service = service;
        this.patientId = patientId;
        this.doctorId = doctorId;
        this.preferredSlot = preferredSlot;
        setPriority(Thread.MAX_PRIORITY);
    }

    @Override
    public void run() {
        try {
            outcome = service.bookAppointment(patientId, doctorId, preferredSlot);
        } catch (DoctorFullyBookedException e) {
            outcome = e.getMessage();
        } catch (DuplicateAppointmentException e) {
            outcome = e.getMessage();
        } catch (InvalidPatientIdException e) {
            outcome = e.getMessage();
        } catch (Exception e) {
            outcome = "Booking failed: " + e.getMessage();
        }
    }

    public String getOutcome() {
        return outcome;
    }
}
