package smarthospital.concurrent;

import smarthospital.model.HospitalNotification;

import java.util.LinkedList;
import java.util.Queue;

/**
 * Shared notification buffer with wait/notify inter-thread communication (CO3).
 */
public class NotificationMonitor {
    private final Queue<HospitalNotification> queue = new LinkedList<HospitalNotification>();
    private boolean shutdown;

    public synchronized void enqueue(HospitalNotification notification) {
        queue.add(notification);
        notifyAll();
    }

    public synchronized HospitalNotification take() throws InterruptedException {
        while (queue.isEmpty() && !shutdown) {
            wait();
        }
        if (queue.isEmpty()) {
            return null;
        }
        return queue.poll();
    }

    public synchronized void shutdown() {
        shutdown = true;
        notifyAll();
    }
}
