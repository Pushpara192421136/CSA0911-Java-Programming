package smarthospital.concurrent;

import smarthospital.model.HospitalNotification;
import smarthospital.service.HospitalService;

/**
 * Background dispatcher. Lower priority than booking workers.
 */
public class NotificationDispatcher extends Thread {
    private final NotificationMonitor monitor;
    private final HospitalService service;
    private volatile boolean running = true;

    public NotificationDispatcher(NotificationMonitor monitor, HospitalService service) {
        super("notification-dispatcher");
        this.monitor = monitor;
        this.service = service;
        setPriority(Thread.NORM_PRIORITY);
    }

    @Override
    public void run() {
        while (running) {
            try {
                HospitalNotification n = monitor.take();
                if (n == null) {
                    break;
                }
                service.deliver(n);
            } catch (InterruptedException e) {
                interrupt();
                break;
            }
        }
    }

    public void requestStop() {
        running = false;
        monitor.shutdown();
    }
}
