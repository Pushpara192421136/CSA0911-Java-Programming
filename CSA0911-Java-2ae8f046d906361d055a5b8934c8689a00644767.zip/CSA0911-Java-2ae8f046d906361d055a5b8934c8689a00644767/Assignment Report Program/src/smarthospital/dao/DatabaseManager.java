package smarthospital.dao;

import smarthospital.jdbc.EmbeddedHospitalDriver;
import smarthospital.model.Appointment;
import smarthospital.model.Doctor;
import smarthospital.model.Medicine;
import smarthospital.model.Patient;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * JDBC persistence for hospital entities. Uses DriverManager, PreparedStatement and ResultSet.
 */
public class DatabaseManager {
    public static final String JDBC_URL = "jdbc:hospital:hospital.db";
    private static DatabaseManager instance;

    private DatabaseManager() {
        EmbeddedHospitalDriver.register();
        initSchema();
    }

    public static synchronized DatabaseManager getInstance() {
        if (instance == null) {
            instance = new DatabaseManager();
        }
        return instance;
    }

    private void initSchema() {
        try (Connection conn = open()) {
            conn.prepareStatement("CREATE TABLE IF NOT EXISTS patients (id TEXT, name TEXT, age INTEGER, category TEXT, phone TEXT)").executeUpdate();
            conn.prepareStatement("CREATE TABLE IF NOT EXISTS doctors (id TEXT, name TEXT, specialization TEXT, slots INTEGER)").executeUpdate();
            conn.prepareStatement("CREATE TABLE IF NOT EXISTS medicines (id TEXT, name TEXT, type TEXT, stock INTEGER, reorder INTEGER, price TEXT)").executeUpdate();
            conn.prepareStatement("CREATE TABLE IF NOT EXISTS appointments (id TEXT, patient_id TEXT, doctor_id TEXT, slot TEXT, status TEXT, notes TEXT)").executeUpdate();
        } catch (SQLException e) {
            throw new IllegalStateException("JDBC schema init failed", e);
        }
    }

    public Connection open() throws SQLException {
        return DriverManager.getConnection(JDBC_URL);
    }

    public void insertPatient(Patient p) throws SQLException {
        try (Connection conn = open();
             PreparedStatement ps = conn.prepareStatement(
                     "INSERT INTO patients (id, name, age, category, phone) VALUES (?, ?, ?, ?, ?)")) {
            ps.setString(1, p.getPatientId());
            ps.setString(2, p.getName());
            ps.setInt(3, p.getAge());
            ps.setString(4, p.getCategory());
            ps.setString(5, p.getPhone());
            ps.executeUpdate();
        }
    }

    public void updatePatient(Patient p) throws SQLException {
        try (Connection conn = open()) {
            PreparedStatement ps = conn.prepareStatement("UPDATE patients SET name = ? WHERE id = ?");
            ps.setString(1, p.getName());
            ps.setString(2, p.getPatientId());
            ps.executeUpdate();
            ps.close();
            ps = conn.prepareStatement("UPDATE patients SET phone = ? WHERE id = ?");
            ps.setString(1, p.getPhone());
            ps.setString(2, p.getPatientId());
            ps.executeUpdate();
            ps.close();
            ps = conn.prepareStatement("UPDATE patients SET age = ? WHERE id = ?");
            ps.setInt(1, p.getAge());
            ps.setString(2, p.getPatientId());
            ps.executeUpdate();
            ps.close();
        }
    }

    public List<Patient> loadPatients() throws SQLException {
        List<Patient> list = new ArrayList<Patient>();
        try (Connection conn = open();
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM patients");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(Patient.create(
                        rs.getString("id"),
                        rs.getString("name"),
                        rs.getInt("age"),
                        rs.getString("phone"),
                        rs.getString("category")));
            }
        }
        return list;
    }

    public void insertDoctor(Doctor d) throws SQLException {
        try (Connection conn = open();
             PreparedStatement ps = conn.prepareStatement(
                     "INSERT INTO doctors (id, name, specialization, slots) VALUES (?, ?, ?, ?)")) {
            ps.setString(1, d.getDoctorId());
            ps.setString(2, d.getName());
            ps.setString(3, d.getSpecialization());
            ps.setInt(4, d.getSlotsPerDay());
            ps.executeUpdate();
        }
    }

    public List<Doctor> loadDoctors() throws SQLException {
        List<Doctor> list = new ArrayList<Doctor>();
        try (Connection conn = open();
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM doctors");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(new Doctor(
                        rs.getString("id"),
                        rs.getString("name"),
                        rs.getString("specialization"),
                        rs.getInt("slots")));
            }
        }
        return list;
    }

    public void insertMedicine(Medicine m) throws SQLException {
        try (Connection conn = open();
             PreparedStatement ps = conn.prepareStatement(
                     "INSERT INTO medicines (id, name, type, stock, reorder, price) VALUES (?, ?, ?, ?, ?, ?)")) {
            ps.setString(1, m.getMedicineId());
            ps.setString(2, m.getName());
            ps.setString(3, m.getType());
            ps.setInt(4, m.getStock());
            ps.setInt(5, m.getReorderLevel());
            ps.setString(6, String.valueOf(m.getUnitPrice()));
            ps.executeUpdate();
        }
    }

    public void updateMedicineStock(String id, int stock) throws SQLException {
        try (Connection conn = open();
             PreparedStatement ps = conn.prepareStatement("UPDATE medicines SET stock = ? WHERE id = ?")) {
            ps.setInt(1, stock);
            ps.setString(2, id);
            ps.executeUpdate();
        }
    }

    public void updateMedicineName(String id, String name) throws SQLException {
        try (Connection conn = open();
             PreparedStatement ps = conn.prepareStatement("UPDATE medicines SET name = ? WHERE id = ?")) {
            ps.setString(1, name);
            ps.setString(2, id);
            ps.executeUpdate();
        }
    }

    public List<Medicine> loadMedicines() throws SQLException {
        List<Medicine> list = new ArrayList<Medicine>();
        try (Connection conn = open();
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM medicines");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(Medicine.create(
                        rs.getString("id"),
                        rs.getString("name"),
                        rs.getString("type"),
                        rs.getInt("stock"),
                        rs.getInt("reorder"),
                        Double.parseDouble(rs.getString("price"))));
            }
        }
        return list;
    }

    public void insertAppointment(Appointment a) throws SQLException {
        try (Connection conn = open();
             PreparedStatement ps = conn.prepareStatement(
                     "INSERT INTO appointments (id, patient_id, doctor_id, slot, status, notes) VALUES (?, ?, ?, ?, ?, ?)")) {
            ps.setString(1, a.getAppointmentId());
            ps.setString(2, a.getPatientId());
            ps.setString(3, a.getDoctorId());
            ps.setString(4, a.getSlot());
            ps.setString(5, a.getStatus());
            ps.setString(6, a.getVisitNotes());
            ps.executeUpdate();
        }
    }

    public void updateAppointmentStatus(String id, String status) throws SQLException {
        try (Connection conn = open();
             PreparedStatement ps = conn.prepareStatement("UPDATE appointments SET status = ? WHERE id = ?")) {
            ps.setString(1, status);
            ps.setString(2, id);
            ps.executeUpdate();
        }
    }

    public List<Appointment> loadAppointments() throws SQLException {
        List<Appointment> list = new ArrayList<Appointment>();
        try (Connection conn = open();
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM appointments");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Appointment a = new Appointment(
                        rs.getString("id"),
                        rs.getString("patient_id"),
                        rs.getString("doctor_id"),
                        rs.getString("slot"),
                        rs.getString("status"));
                a.setVisitNotes(rs.getString("notes"));
                list.add(a);
            }
        }
        return list;
    }
}
