package smarthospital.service;

import smarthospital.concurrent.NotificationDispatcher;
import smarthospital.concurrent.NotificationMonitor;
import smarthospital.dao.DatabaseManager;
import smarthospital.exception.DoctorFullyBookedException;
import smarthospital.exception.DuplicateAppointmentException;
import smarthospital.exception.InvalidInputException;
import smarthospital.exception.InvalidPatientIdException;
import smarthospital.exception.OutOfStockException;
import smarthospital.model.Appointment;
import smarthospital.model.AppointmentReminderNotification;
import smarthospital.model.Doctor;
import smarthospital.model.HospitalNotification;
import smarthospital.model.Inventory;
import smarthospital.model.LowStockNotification;
import smarthospital.model.Medicine;
import smarthospital.model.Patient;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;

/**
 * In-memory domain services backed by JDBC. Collections, iterators, locking and waitlists live here.
 */
public class HospitalService {
    public static final double BASE_CONSULTATION_FEE = 500.0;

    private static HospitalService instance;

    private final DatabaseManager db = DatabaseManager.getInstance();
    private final HashMap<String, Patient> patientsById = new HashMap<String, Patient>();
    private final ArrayList<Patient> patients = new ArrayList<Patient>();
    private final HashMap<String, Doctor> doctorsById = new HashMap<String, Doctor>();
    private final ArrayList<Doctor> doctors = new ArrayList<Doctor>();
    private final HashMap<String, Medicine> medicinesById = new HashMap<String, Medicine>();
    private final ArrayList<Medicine> medicines = new ArrayList<Medicine>();
    private final ArrayList<Appointment> appointments = new ArrayList<Appointment>();
    private final HashMap<String, LinkedList<String>> waitlistByDoctor = new HashMap<String, LinkedList<String>>();
    private final HashMap<String, HashSet<String>> bookedSlotsByDoctor = new HashMap<String, HashSet<String>>();
    private final Set<String> specializations = new HashSet<String>();
    private final Inventory inventory = new Inventory();
    private final ArrayList<HospitalNotification> deliveredNotifications = new ArrayList<HospitalNotification>();
    private final NotificationMonitor notificationMonitor = new NotificationMonitor();
    private final NotificationDispatcher dispatcher;

    private int patientSeq = 1;
    private int doctorSeq = 1;
    private int medicineSeq = 1;
    private int appointmentSeq = 1;
    private int notificationSeq = 1;

    private HospitalService() {
        dispatcher = new NotificationDispatcher(notificationMonitor, this);
        dispatcher.start();
        loadFromDatabase();
        if (doctors.isEmpty()) {
            seedDemoData();
        }
    }

    public static synchronized HospitalService getInstance() {
        if (instance == null) {
            instance = new HospitalService();
        }
        return instance;
    }

    private void loadFromDatabase() {
        try {
            for (Patient p : db.loadPatients()) {
                patients.add(p);
                patientsById.put(p.getPatientId(), p);
                patientSeq = Math.max(patientSeq, parseSeq(p.getPatientId(), 'P') + 1);
            }
            for (Doctor d : db.loadDoctors()) {
                doctors.add(d);
                doctorsById.put(d.getDoctorId(), d);
                specializations.add(d.getSpecialization());
                bookedSlotsByDoctor.put(d.getDoctorId(), new HashSet<String>());
                waitlistByDoctor.put(d.getDoctorId(), new LinkedList<String>());
                doctorSeq = Math.max(doctorSeq, parseSeq(d.getDoctorId(), 'D') + 1);
            }
            for (Medicine m : db.loadMedicines()) {
                medicines.add(m);
                medicinesById.put(m.getMedicineId(), m);
                inventory.put(m.getMedicineId(), m.getStock());
                medicineSeq = Math.max(medicineSeq, parseSeq(m.getMedicineId(), 'M') + 1);
            }
            for (Appointment a : db.loadAppointments()) {
                appointments.add(a);
                appointmentSeq = Math.max(appointmentSeq, parseSeq(a.getAppointmentId(), 'A') + 1);
                if ("BOOKED".equals(a.getStatus())) {
                    HashSet<String> slots = bookedSlotsByDoctor.get(a.getDoctorId());
                    if (slots != null) {
                        slots.add(a.getSlot());
                    }
                }
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to load JDBC data", e);
        }
    }

    private void seedDemoData() {
        try {
            registerDoctor("Dr. Meera Nair", "Cardiology", 4);
            registerDoctor("Dr. Arun Kumar", "General Medicine", 3);
            registerDoctor("Dr. Kavya Rao", "Pediatrics", 3);
            addMedicine("Paracetamol 500mg", "TABLET", 20, 5, 2.50);
            addMedicine("Amoxicillin 250mg", "TABLET", 8, 5, 6.00);
            addMedicine("Cough Syrup", "SYRUP", 4, 5, 45.00);
            registerPatient("Anita Sharma", 67, "9000000001", "SENIOR");
            registerPatient("Rahul Verma", 32, "9000000002", "REGULAR");
            registerPatient("Ishaan Patel", 8, "9000000003", "PEDIATRIC");
        } catch (Exception ignored) {
            // seed is best-effort
        }
    }

    private int parseSeq(String id, char prefix) {
        try {
            if (id != null && id.length() > 1 && id.charAt(0) == prefix) {
                return Integer.parseInt(id.substring(1));
            }
        } catch (NumberFormatException ignored) {
        }
        return 0;
    }

    private String nextId(char prefix, int seq) {
        return String.format("%c%03d", Character.valueOf(prefix), Integer.valueOf(seq));
    }

    public synchronized Patient registerPatient(String name, int age, String phone, String category)
            throws InvalidInputException, SQLException {
        validateName(name);
        if (age <= 0 || age > 120) {
            throw new InvalidInputException("Age must be between 1 and 120");
        }
        if (phone == null || phone.trim().length() < 8) {
            throw new InvalidInputException("Phone number is too short");
        }
        String id = nextId('P', patientSeq++);
        Patient p = Patient.create(id, name.trim(), age, phone.trim(), category);
        patients.add(p);
        patientsById.put(id, p);
        db.insertPatient(p);
        return p;
    }

    public synchronized Doctor registerDoctor(String name, String specialization, int slots)
            throws InvalidInputException, SQLException {
        validateName(name);
        if (specialization == null || specialization.trim().isEmpty()) {
            throw new InvalidInputException("Specialization is required");
        }
        if (slots < 1 || slots > 8) {
            throw new InvalidInputException("Slots per day must be between 1 and 8");
        }
        String id = nextId('D', doctorSeq++);
        Doctor d = new Doctor(id, name.trim(), specialization.trim(), slots);
        doctors.add(d);
        doctorsById.put(id, d);
        specializations.add(d.getSpecialization());
        bookedSlotsByDoctor.put(id, new HashSet<String>());
        waitlistByDoctor.put(id, new LinkedList<String>());
        db.insertDoctor(d);
        return d;
    }

    public synchronized Medicine addMedicine(String name, String type, int stock, int reorder, double price)
            throws InvalidInputException, SQLException {
        validateName(name);
        if (stock < 0 || reorder < 0 || price < 0) {
            throw new InvalidInputException("Stock, reorder level and price cannot be negative");
        }
        String id = nextId('M', medicineSeq++);
        Medicine m = Medicine.create(id, name.trim(), type, stock, reorder, price);
        medicines.add(m);
        medicinesById.put(id, m);
        inventory.put(id, stock);
        db.insertMedicine(m);
        if (m.isLowStock()) {
            enqueueLowStock(m);
        }
        return m;
    }

    public synchronized String bookAppointment(String patientId, String doctorId, String preferredSlot)
            throws InvalidPatientIdException, DuplicateAppointmentException, DoctorFullyBookedException,
            InvalidInputException, SQLException {
        Patient patient = requirePatient(patientId);
        Doctor doctor = doctorsById.get(doctorId);
        if (doctor == null) {
            throw new InvalidInputException("Unknown doctor ID: " + doctorId);
        }
        Iterator<Appointment> it = appointments.iterator();
        while (it.hasNext()) {
            Appointment existing = it.next();
            if (existing.getPatientId().equals(patientId)
                    && existing.getDoctorId().equals(doctorId)
                    && "BOOKED".equals(existing.getStatus())) {
                throw new DuplicateAppointmentException(
                        "Patient " + patientId + " already has a booked appointment with " + doctorId);
            }
        }
        HashSet<String> booked = bookedSlotsByDoctor.get(doctorId);
        String slot = preferredSlot;
        if (slot == null || slot.trim().isEmpty() || booked.contains(slot) || !doctor.getDefaultSlots().contains(slot)) {
            slot = firstFreeSlot(doctor, booked);
        }
        if (slot == null) {
            waitlistByDoctor.get(doctorId).add(patient.getPatientId());
            throw new DoctorFullyBookedException(doctorId);
        }
        String id = nextId('A', appointmentSeq++);
        Appointment appointment = new Appointment(id, patientId, doctorId, slot, "BOOKED");
        appointment.setVisitNotes("Consultation fee Rs." + patient.getConsultationFee(BASE_CONSULTATION_FEE));
        appointments.add(appointment);
        booked.add(slot);
        db.insertAppointment(appointment);
        HospitalNotification reminder = new AppointmentReminderNotification(
                nextId('N', notificationSeq++), patientId, slot, doctor.getName());
        notificationMonitor.enqueue(reminder);
        return appointment.toString();
    }

    private String firstFreeSlot(Doctor doctor, Set<String> booked) {
        for (String slot : doctor.getDefaultSlots()) {
            if (!booked.contains(slot)) {
                return slot;
            }
        }
        return null;
    }

    public synchronized String cancelAppointment(String appointmentId) throws InvalidInputException, SQLException {
        ListIterator<Appointment> iterator = appointments.listIterator();
        Appointment found = null;
        while (iterator.hasNext()) {
            Appointment a = iterator.next();
            if (a.getAppointmentId().equals(appointmentId)) {
                found = a;
                break;
            }
        }
        if (found == null) {
            throw new InvalidInputException("Appointment not found: " + appointmentId);
        }
        if (!"BOOKED".equals(found.getStatus())) {
            throw new InvalidInputException("Only BOOKED appointments can be cancelled");
        }
        found.setStatus("CANCELLED");
        db.updateAppointmentStatus(appointmentId, "CANCELLED");
        HashSet<String> booked = bookedSlotsByDoctor.get(found.getDoctorId());
        if (booked != null) {
            booked.remove(found.getSlot());
        }
        LinkedList<String> wait = waitlistByDoctor.get(found.getDoctorId());
        if (wait != null && !wait.isEmpty()) {
            String nextPatient = wait.removeFirst();
            try {
                bookAppointment(nextPatient, found.getDoctorId(), found.getSlot());
                return "Cancelled " + appointmentId + ". Waitlisted patient " + nextPatient + " was auto-booked.";
            } catch (Exception e) {
                return "Cancelled " + appointmentId + ". Waitlist promotion failed: " + e.getMessage();
            }
        }
        return "Cancelled " + appointmentId;
    }

    public synchronized String dispenseMedicine(String medicineId, int qty)
            throws OutOfStockException, InvalidInputException, SQLException {
        if (qty <= 0) {
            throw new InvalidInputException("Quantity must be positive");
        }
        Medicine m = medicinesById.get(medicineId);
        if (m == null) {
            throw new InvalidInputException("Unknown medicine ID: " + medicineId);
        }
        synchronized (inventory) {
            if (!inventory.reduce(medicineId, qty)) {
                throw new OutOfStockException(m.getName());
            }
            m.setStock(inventory.getQuantity(medicineId));
        }
        db.updateMedicineStock(medicineId, m.getStock());
        if (m.isLowStock()) {
            enqueueLowStock(m);
        }
        return "Dispensed " + qty + " of " + m.getName() + " | " + m.getDosageInstructions()
                + " | remaining=" + m.getStock();
    }

    private void enqueueLowStock(Medicine m) {
        HospitalNotification alert = new LowStockNotification(
                nextId('N', notificationSeq++), m.getMedicineId(), m.getName(), m.getStock());
        notificationMonitor.enqueue(alert);
    }

    public synchronized void deliver(HospitalNotification notification) {
        notification.markDelivered();
        deliveredNotifications.add(notification);
    }

    public Patient requirePatient(String patientId) throws InvalidPatientIdException {
        if (patientId == null || !patientsById.containsKey(patientId)) {
            throw new InvalidPatientIdException(patientId);
        }
        return patientsById.get(patientId);
    }

    public synchronized Patient updatePatient(String patientId, String name, String phone, Integer age)
            throws InvalidPatientIdException, InvalidInputException, SQLException {
        Patient p = requirePatient(patientId);
        if (name != null && !name.trim().isEmpty()) {
            p.setName(name.trim());
        }
        if (phone != null && !phone.trim().isEmpty()) {
            p.setPhone(phone.trim());
        }
        if (age != null) {
            if (age.intValue() <= 0 || age.intValue() > 120) {
                throw new InvalidInputException("Age must be between 1 and 120");
            }
            p.setAge(age.intValue());
        }
        db.updatePatient(p);
        return p;
    }

    public synchronized Medicine updateMedicine(String medicineId, String name, Integer stock)
            throws InvalidInputException, SQLException {
        Medicine m = medicinesById.get(medicineId);
        if (m == null) {
            throw new InvalidInputException("Unknown medicine ID: " + medicineId);
        }
        if (name != null && !name.trim().isEmpty()) {
            m.setName(name.trim());
            db.updateMedicineName(medicineId, m.getName());
        }
        if (stock != null) {
            if (stock.intValue() < 0) {
                throw new InvalidInputException("Stock cannot be negative");
            }
            m.setStock(stock.intValue());
            inventory.put(medicineId, stock.intValue());
            db.updateMedicineStock(medicineId, stock.intValue());
            if (m.isLowStock()) {
                enqueueLowStock(m);
            }
        }
        return m;
    }

    public List<Patient> getPatients() {
        return new ArrayList<Patient>(patients);
    }

    public List<Doctor> getDoctors() {
        return new ArrayList<Doctor>(doctors);
    }

    public List<Medicine> getMedicines() {
        return new ArrayList<Medicine>(medicines);
    }

    public List<Appointment> getAppointments() {
        return new ArrayList<Appointment>(appointments);
    }

    public Set<String> getSpecializations() {
        return new HashSet<String>(specializations);
    }

    public String availableSlotsReport() {
        StringBuilder sb = new StringBuilder();
        Iterator<Doctor> it = doctors.iterator();
        while (it.hasNext()) {
            Doctor d = it.next();
            HashSet<String> booked = bookedSlotsByDoctor.get(d.getDoctorId());
            sb.append(d).append('\n');
            sb.append("  Free slots: ");
            boolean any = false;
            for (String slot : d.getDefaultSlots()) {
                if (booked == null || !booked.contains(slot)) {
                    sb.append(slot).append(' ');
                    any = true;
                }
            }
            if (!any) {
                sb.append("(none)");
            }
            LinkedList<String> wait = waitlistByDoctor.get(d.getDoctorId());
            sb.append("\n  Waitlist size: ").append(wait == null ? 0 : wait.size()).append("\n");
        }
        return sb.toString();
    }

    public String waitlistReport() {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, LinkedList<String>> e : waitlistByDoctor.entrySet()) {
            sb.append(e.getKey()).append(" -> ").append(e.getValue()).append('\n');
        }
        return sb.length() == 0 ? "No waitlists.\n" : sb.toString();
    }

    public String stockReport() {
        StringBuilder sb = new StringBuilder();
        Iterator<Medicine> it = medicines.iterator();
        while (it.hasNext()) {
            Medicine m = it.next();
            sb.append(m).append(m.isLowStock() ? "  ** LOW STOCK **" : "").append('\n');
            sb.append("  Dosage: ").append(m.getDosageInstructions()).append('\n');
        }
        return sb.toString();
    }

    public String patientVisitReport() {
        StringBuilder sb = new StringBuilder();
        sb.append("===== PATIENT VISIT REPORT =====\n");
        sb.append("Total patients: ").append(patients.size()).append('\n');
        int booked = 0;
        int cancelled = 0;
        double fees = 0;
        Iterator<Appointment> it = appointments.iterator();
        while (it.hasNext()) {
            Appointment a = it.next();
            if ("BOOKED".equals(a.getStatus())) {
                booked++;
                Patient p = patientsById.get(a.getPatientId());
                if (p != null) {
                    fees += p.getConsultationFee(BASE_CONSULTATION_FEE);
                }
            } else if ("CANCELLED".equals(a.getStatus())) {
                cancelled++;
            }
            sb.append(a).append(" | ").append(a.getVisitNotes()).append('\n');
        }
        sb.append("Booked=").append(booked).append(" Cancelled=").append(cancelled)
                .append(" Fee collection Rs.").append(fees).append('\n');
        sb.append("Specializations offered: ").append(specializations).append('\n');
        return sb.toString();
    }

    public String pharmacyUtilizationReport() {
        StringBuilder sb = new StringBuilder();
        sb.append("===== PHARMACY INVENTORY UTILIZATION =====\n");
        int totalUnits = 0;
        int low = 0;
        Iterator<Medicine> it = medicines.iterator();
        while (it.hasNext()) {
            Medicine m = it.next();
            totalUnits += m.getStock();
            if (m.isLowStock()) {
                low++;
            }
            sb.append(m.getMedicineId()).append(" hashtableQty=")
                    .append(inventory.getQuantity(m.getMedicineId()))
                    .append(" | ").append(m.getName()).append('\n');
        }
        sb.append("Total units on shelf=").append(totalUnits).append(" low-stock items=").append(low).append('\n');
        sb.append("Delivered notifications: ").append(deliveredNotifications.size()).append('\n');
        for (HospitalNotification n : deliveredNotifications) {
            sb.append("  ").append(n).append('\n');
        }
        return sb.toString();
    }

    public List<HospitalNotification> getDeliveredNotifications() {
        return new ArrayList<HospitalNotification>(deliveredNotifications);
    }

    public void shutdown() {
        dispatcher.requestStop();
        try {
            dispatcher.join(1500);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private void validateName(String name) throws InvalidInputException {
        if (name == null || name.trim().isEmpty()) {
            throw new InvalidInputException("Name cannot be empty");
        }
    }
}
