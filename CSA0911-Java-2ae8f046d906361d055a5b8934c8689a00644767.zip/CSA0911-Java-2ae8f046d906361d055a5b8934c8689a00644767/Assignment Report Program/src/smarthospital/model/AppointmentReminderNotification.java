package smarthospital.model;

public class AppointmentReminderNotification extends HospitalNotification {
    private final String slot;
    private final String doctorName;

    public AppointmentReminderNotification(String notificationId, String patientId, String slot, String doctorName) {
        super(notificationId, patientId);
        this.slot = slot;
        this.doctorName = doctorName;
    }

    @Override
    public String getType() {
        return "APPOINTMENT_REMINDER";
    }

    @Override
    public String formatMessage() {
        return "Reminder: appointment with " + doctorName + " at " + slot + " today.";
    }
}
