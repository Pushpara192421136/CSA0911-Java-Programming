package smarthospital.model;

public class RegularPatient extends Patient {
    public RegularPatient(String patientId, String name, int age, String phone) {
        super(patientId, name, age, phone);
    }

    @Override
    public String getCategory() {
        return "REGULAR";
    }

    @Override
    public double getConsultationFee(double baseFee) {
        return baseFee;
    }
}
