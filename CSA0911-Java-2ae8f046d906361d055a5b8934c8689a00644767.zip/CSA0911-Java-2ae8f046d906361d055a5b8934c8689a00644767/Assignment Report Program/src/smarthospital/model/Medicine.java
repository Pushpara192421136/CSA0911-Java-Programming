package smarthospital.model;

/**
 * Base medicine entity. Subclasses provide dosage rules via polymorphism.
 */
public abstract class Medicine {
    private String medicineId;
    private String name;
    private int stock;
    private int reorderLevel;
    private double unitPrice;

    protected Medicine(String medicineId, String name, int stock, int reorderLevel, double unitPrice) {
        this.medicineId = medicineId;
        this.name = name;
        this.stock = stock;
        this.reorderLevel = reorderLevel;
        this.unitPrice = unitPrice;
    }

    public String getMedicineId() {
        return medicineId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public int getReorderLevel() {
        return reorderLevel;
    }

    public void setReorderLevel(int reorderLevel) {
        this.reorderLevel = reorderLevel;
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
    }

    public abstract String getType();

    public abstract String getDosageInstructions();

    public boolean isLowStock() {
        return stock <= reorderLevel;
    }

    @Override
    public String toString() {
        return medicineId + " | " + name + " | " + getType() + " | stock=" + stock
                + " | reorder=" + reorderLevel + " | Rs." + unitPrice;
    }

    public static Medicine create(String id, String name, String type, int stock, int reorder, double price) {
        String t = type == null ? "TABLET" : type.trim().toUpperCase();
        if (t.startsWith("SYR")) {
            return new SyrupMedicine(id, name, stock, reorder, price);
        }
        return new TabletMedicine(id, name, stock, reorder, price);
    }
}
