package smarthospital.model;

import java.util.Enumeration;
import java.util.Hashtable;

/**
 * Thread-safe pharmacy stock using Hashtable as required by CO2.
 */
public class Inventory {
    private final Hashtable<String, Integer> stockByMedicineId = new Hashtable<String, Integer>();

    public synchronized void put(String medicineId, int qty) {
        stockByMedicineId.put(medicineId, Integer.valueOf(qty));
    }

    public synchronized int getQuantity(String medicineId) {
        Integer q = stockByMedicineId.get(medicineId);
        return q == null ? 0 : q.intValue();
    }

    public synchronized boolean reduce(String medicineId, int qty) {
        int current = getQuantity(medicineId);
        if (current < qty) {
            return false;
        }
        stockByMedicineId.put(medicineId, Integer.valueOf(current - qty));
        return true;
    }

    public synchronized Enumeration<String> keys() {
        return stockByMedicineId.keys();
    }

    public Hashtable<String, Integer> snapshot() {
        return new Hashtable<String, Integer>(stockByMedicineId);
    }
}
