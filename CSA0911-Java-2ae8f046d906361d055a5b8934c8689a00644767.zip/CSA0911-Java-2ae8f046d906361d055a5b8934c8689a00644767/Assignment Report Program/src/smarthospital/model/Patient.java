package smarthospital.model;

/**
 * Base patient entity. Subclasses apply consultation-fee waivers at run time (polymorphism).
 */
public abstract class Patient {
    private String patientId;
    private String name;
    private int age;
    private String phone;

    protected Patient(String patientId, String name, int age, String phone) {
        this.patientId = patientId;
        this.name = name;
        this.age = age;
        this.phone = phone;
    }

    public String getPatientId() {
        return patientId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public abstract String getCategory();

    public abstract double getConsultationFee(double baseFee);

    @Override
    public String toString() {
        return patientId + " | " + name + " | age " + age + " | " + getCategory() + " | " + phone;
    }

    public static Patient create(String id, String name, int age, String phone, String category) {
        String cat = category == null ? "REGULAR" : category.trim().toUpperCase();
        if (cat.startsWith("SENIOR")) {
            return new SeniorCitizenPatient(id, name, age, phone);
        }
        if (cat.startsWith("PED") || cat.startsWith("CHILD")) {
            return new PediatricPatient(id, name, age, phone);
        }
        return new RegularPatient(id, name, age, phone);
    }
}
