package smarthospital.model;

public class TabletMedicine extends Medicine {
    public TabletMedicine(String medicineId, String name, int stock, int reorderLevel, double unitPrice) {
        super(medicineId, name, stock, reorderLevel, unitPrice);
    }

    @Override
    public String getType() {
        return "TABLET";
    }

    @Override
    public String getDosageInstructions() {
        return "Take 1 tablet after food, twice daily.";
    }
}
