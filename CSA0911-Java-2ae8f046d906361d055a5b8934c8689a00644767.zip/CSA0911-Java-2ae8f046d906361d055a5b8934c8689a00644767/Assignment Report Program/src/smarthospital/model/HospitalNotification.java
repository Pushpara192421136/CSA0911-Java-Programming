package smarthospital.model;

/**
 * Base notification. Subclasses change message format and channel at run time.
 */
public abstract class HospitalNotification {
    private final String notificationId;
    private final String targetId;
    private boolean delivered;

    protected HospitalNotification(String notificationId, String targetId) {
        this.notificationId = notificationId;
        this.targetId = targetId;
        this.delivered = false;
    }

    public String getNotificationId() {
        return notificationId;
    }

    public String getTargetId() {
        return targetId;
    }

    public boolean isDelivered() {
        return delivered;
    }

    public void markDelivered() {
        this.delivered = true;
    }

    public abstract String getType();

    public abstract String formatMessage();

    @Override
    public String toString() {
        return getType() + " [" + notificationId + "] -> " + targetId + " | " + formatMessage();
    }
}
