package smarthospital.model;

public class SyrupMedicine extends Medicine {
    public SyrupMedicine(String medicineId, String name, int stock, int reorderLevel, double unitPrice) {
        super(medicineId, name, stock, reorderLevel, unitPrice);
    }

    @Override
    public String getType() {
        return "SYRUP";
    }

    @Override
    public String getDosageInstructions() {
        return "Take 5 ml twice daily. Shake the bottle well.";
    }
}
