package smarthospital.model;

public class LowStockNotification extends HospitalNotification {
    private final String medicineName;
    private final int remaining;

    public LowStockNotification(String notificationId, String medicineId, String medicineName, int remaining) {
        super(notificationId, medicineId);
        this.medicineName = medicineName;
        this.remaining = remaining;
    }

    @Override
    public String getType() {
        return "LOW_STOCK_ALERT";
    }

    @Override
    public String formatMessage() {
        return "Low stock: " + medicineName + " remaining=" + remaining + ". Reorder required.";
    }
}
