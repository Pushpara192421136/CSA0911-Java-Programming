package smarthospital.model;

public class PediatricPatient extends Patient {
    public PediatricPatient(String patientId, String name, int age, String phone) {
        super(patientId, name, age, phone);
    }

    @Override
    public String getCategory() {
        return "PEDIATRIC";
    }

    @Override
    public double getConsultationFee(double baseFee) {
        return baseFee * 0.75;
    }
}
