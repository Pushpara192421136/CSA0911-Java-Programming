package smarthospital.model;

import java.util.LinkedHashSet;
import java.util.Set;

public class Doctor {
    private String doctorId;
    private String name;
    private String specialization;
    private int slotsPerDay;
    private final Set<String> defaultSlots;

    public Doctor(String doctorId, String name, String specialization, int slotsPerDay) {
        this.doctorId = doctorId;
        this.name = name;
        this.specialization = specialization;
        this.slotsPerDay = slotsPerDay;
        this.defaultSlots = new LinkedHashSet<String>();
        String[] catalog = {"09:00", "10:00", "11:00", "12:00", "14:00", "15:00", "16:00", "17:00"};
        int n = Math.min(slotsPerDay, catalog.length);
        for (int i = 0; i < n; i++) {
            defaultSlots.add(catalog[i]);
        }
    }

    public String getDoctorId() {
        return doctorId;
    }

    public String getName() {
        return name;
    }

    public String getSpecialization() {
        return specialization;
    }

    public int getSlotsPerDay() {
        return slotsPerDay;
    }

    public Set<String> getDefaultSlots() {
        return new LinkedHashSet<String>(defaultSlots);
    }

    @Override
    public String toString() {
        return doctorId + " | " + name + " | " + specialization + " | slots/day=" + slotsPerDay;
    }
}
