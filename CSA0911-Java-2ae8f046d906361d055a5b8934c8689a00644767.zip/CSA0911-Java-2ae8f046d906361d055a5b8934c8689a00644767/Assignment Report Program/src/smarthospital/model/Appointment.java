package smarthospital.model;

public class Appointment {
    private String appointmentId;
    private String patientId;
    private String doctorId;
    private String slot;
    private String status;
    private String visitNotes;

    public Appointment(String appointmentId, String patientId, String doctorId, String slot, String status) {
        this.appointmentId = appointmentId;
        this.patientId = patientId;
        this.doctorId = doctorId;
        this.slot = slot;
        this.status = status;
        this.visitNotes = "";
    }

    public String getAppointmentId() {
        return appointmentId;
    }

    public String getPatientId() {
        return patientId;
    }

    public String getDoctorId() {
        return doctorId;
    }

    public String getSlot() {
        return slot;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getVisitNotes() {
        return visitNotes;
    }

    public void setVisitNotes(String visitNotes) {
        this.visitNotes = visitNotes;
    }

    @Override
    public String toString() {
        return appointmentId + " | patient=" + patientId + " | doctor=" + doctorId
                + " | slot=" + slot + " | " + status;
    }
}
