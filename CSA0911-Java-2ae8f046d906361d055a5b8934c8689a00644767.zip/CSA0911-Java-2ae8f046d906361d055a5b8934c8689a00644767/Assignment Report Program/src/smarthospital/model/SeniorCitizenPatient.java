package smarthospital.model;

/** SDG 10: reduced inequality through a senior consultation-fee waiver. */
public class SeniorCitizenPatient extends Patient {
    public SeniorCitizenPatient(String patientId, String name, int age, String phone) {
        super(patientId, name, age, phone);
    }

    @Override
    public String getCategory() {
        return "SENIOR";
    }

    @Override
    public double getConsultationFee(double baseFee) {
        return baseFee * 0.50;
    }
}
