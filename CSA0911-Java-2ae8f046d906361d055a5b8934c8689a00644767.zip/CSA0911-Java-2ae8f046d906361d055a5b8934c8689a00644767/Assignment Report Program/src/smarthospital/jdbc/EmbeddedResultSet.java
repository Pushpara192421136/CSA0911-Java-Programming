package smarthospital.jdbc;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Date;
import java.sql.NClob;
import java.sql.Ref;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.RowId;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.SQLXML;
import java.sql.Statement;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

class EmbeddedResultSet implements ResultSet {
    private final List<Map<String, String>> rows;
    private int cursor = -1;
    private boolean closed;

    EmbeddedResultSet(List<Map<String, String>> rows) {
        this.rows = rows;
    }

    private Map<String, String> current() throws SQLException {
        if (cursor < 0 || cursor >= rows.size()) {
            throw new SQLException("No current row");
        }
        return rows.get(cursor);
    }

    @Override
    public boolean next() {
        cursor++;
        return cursor < rows.size();
    }

    @Override
    public String getString(String columnLabel) throws SQLException {
        return current().get(columnLabel.toLowerCase());
    }

    @Override
    public int getInt(String columnLabel) throws SQLException {
        String v = getString(columnLabel);
        if (v == null || v.isEmpty()) {
            return 0;
        }
        return Integer.parseInt(v);
    }

    @Override
    public double getDouble(String columnLabel) throws SQLException {
        String v = getString(columnLabel);
        if (v == null || v.isEmpty()) {
            return 0.0;
        }
        return Double.parseDouble(v);
    }

    @Override
    public void close() {
        closed = true;
    }

    @Override
    public boolean isClosed() {
        return closed;
    }

    @Override
    public boolean wasNull() {
        return false;
    }

    @Override
    public String getString(int columnIndex) throws SQLException {
        Map<String, String> row = current();
        String[] keys = row.keySet().toArray(new String[0]);
        return row.get(keys[columnIndex - 1]);
    }

    @Override
    public boolean getBoolean(int columnIndex) {
        return false;
    }

    @Override
    public byte getByte(int columnIndex) {
        return 0;
    }

    @Override
    public short getShort(int columnIndex) {
        return 0;
    }

    @Override
    public int getInt(int columnIndex) throws SQLException {
        String v = getString(columnIndex);
        return v == null || v.isEmpty() ? 0 : Integer.parseInt(v);
    }

    @Override
    public long getLong(int columnIndex) throws SQLException {
        return getInt(columnIndex);
    }

    @Override
    public float getFloat(int columnIndex) throws SQLException {
        return (float) getDouble(columnIndex);
    }

    @Override
    public double getDouble(int columnIndex) throws SQLException {
        String v = getString(columnIndex);
        return v == null || v.isEmpty() ? 0.0 : Double.parseDouble(v);
    }

    @Override
    public BigDecimal getBigDecimal(int columnIndex, int scale) {
        return BigDecimal.ZERO;
    }

    @Override
    public byte[] getBytes(int columnIndex) {
        return new byte[0];
    }

    @Override
    public Date getDate(int columnIndex) {
        return null;
    }

    @Override
    public Time getTime(int columnIndex) {
        return null;
    }

    @Override
    public Timestamp getTimestamp(int columnIndex) {
        return null;
    }

    @Override
    public InputStream getAsciiStream(int columnIndex) {
        return null;
    }

    @Override
    public InputStream getUnicodeStream(int columnIndex) {
        return null;
    }

    @Override
    public InputStream getBinaryStream(int columnIndex) {
        return null;
    }

    @Override
    public boolean getBoolean(String columnLabel) {
        return false;
    }

    @Override
    public byte getByte(String columnLabel) {
        return 0;
    }

    @Override
    public short getShort(String columnLabel) {
        return 0;
    }

    @Override
    public long getLong(String columnLabel) throws SQLException {
        return getInt(columnLabel);
    }

    @Override
    public float getFloat(String columnLabel) throws SQLException {
        return (float) getDouble(columnLabel);
    }

    @Override
    public BigDecimal getBigDecimal(String columnLabel, int scale) {
        return BigDecimal.ZERO;
    }

    @Override
    public byte[] getBytes(String columnLabel) {
        return new byte[0];
    }

    @Override
    public Date getDate(String columnLabel) {
        return null;
    }

    @Override
    public Time getTime(String columnLabel) {
        return null;
    }

    @Override
    public Timestamp getTimestamp(String columnLabel) {
        return null;
    }

    @Override
    public InputStream getAsciiStream(String columnLabel) {
        return null;
    }

    @Override
    public InputStream getUnicodeStream(String columnLabel) {
        return null;
    }

    @Override
    public InputStream getBinaryStream(String columnLabel) {
        return null;
    }

    @Override
    public SQLWarning getWarnings() {
        return null;
    }

    @Override
    public void clearWarnings() {
    }

    @Override
    public String getCursorName() {
        return "";
    }

    @Override
    public ResultSetMetaData getMetaData() {
        return null;
    }

    @Override
    public Object getObject(int columnIndex) throws SQLException {
        return getString(columnIndex);
    }

    @Override
    public Object getObject(String columnLabel) throws SQLException {
        return getString(columnLabel);
    }

    @Override
    public int findColumn(String columnLabel) {
        return 1;
    }

    @Override
    public Reader getCharacterStream(int columnIndex) {
        return null;
    }

    @Override
    public Reader getCharacterStream(String columnLabel) {
        return null;
    }

    @Override
    public BigDecimal getBigDecimal(int columnIndex) {
        return BigDecimal.ZERO;
    }

    @Override
    public BigDecimal getBigDecimal(String columnLabel) {
        return BigDecimal.ZERO;
    }

    @Override
    public boolean isBeforeFirst() {
        return cursor < 0;
    }

    @Override
    public boolean isAfterLast() {
        return cursor >= rows.size();
    }

    @Override
    public boolean isFirst() {
        return cursor == 0;
    }

    @Override
    public boolean isLast() {
        return cursor == rows.size() - 1;
    }

    @Override
    public void beforeFirst() {
        cursor = -1;
    }

    @Override
    public void afterLast() {
        cursor = rows.size();
    }

    @Override
    public boolean first() {
        cursor = 0;
        return !rows.isEmpty();
    }

    @Override
    public boolean last() {
        cursor = rows.size() - 1;
        return !rows.isEmpty();
    }

    @Override
    public int getRow() {
        return cursor + 1;
    }

    @Override
    public boolean absolute(int row) {
        cursor = row - 1;
        return cursor >= 0 && cursor < rows.size();
    }

    @Override
    public boolean relative(int rows) {
        cursor += rows;
        return cursor >= 0 && cursor < this.rows.size();
    }

    @Override
    public boolean previous() {
        cursor--;
        return cursor >= 0;
    }

    @Override
    public void setFetchDirection(int direction) {
    }

    @Override
    public int getFetchDirection() {
        return ResultSet.FETCH_FORWARD;
    }

    @Override
    public void setFetchSize(int rows) {
    }

    @Override
    public int getFetchSize() {
        return 0;
    }

    @Override
    public int getType() {
        return ResultSet.TYPE_FORWARD_ONLY;
    }

    @Override
    public int getConcurrency() {
        return ResultSet.CONCUR_READ_ONLY;
    }

    @Override
    public boolean rowUpdated() {
        return false;
    }

    @Override
    public boolean rowInserted() {
        return false;
    }

    @Override
    public boolean rowDeleted() {
        return false;
    }

    @Override
    public void updateNull(int columnIndex) {
    }

    @Override
    public void updateBoolean(int columnIndex, boolean x) {
    }

    @Override
    public void updateByte(int columnIndex, byte x) {
    }

    @Override
    public void updateShort(int columnIndex, short x) {
    }

    @Override
    public void updateInt(int columnIndex, int x) {
    }

    @Override
    public void updateLong(int columnIndex, long x) {
    }

    @Override
    public void updateFloat(int columnIndex, float x) {
    }

    @Override
    public void updateDouble(int columnIndex, double x) {
    }

    @Override
    public void updateBigDecimal(int columnIndex, BigDecimal x) {
    }

    @Override
    public void updateString(int columnIndex, String x) {
    }

    @Override
    public void updateBytes(int columnIndex, byte[] x) {
    }

    @Override
    public void updateDate(int columnIndex, Date x) {
    }

    @Override
    public void updateTime(int columnIndex, Time x) {
    }

    @Override
    public void updateTimestamp(int columnIndex, Timestamp x) {
    }

    @Override
    public void updateAsciiStream(int columnIndex, InputStream x, int length) {
    }

    @Override
    public void updateBinaryStream(int columnIndex, InputStream x, int length) {
    }

    @Override
    public void updateCharacterStream(int columnIndex, Reader x, int length) {
    }

    @Override
    public void updateObject(int columnIndex, Object x, int scaleOrLength) {
    }

    @Override
    public void updateObject(int columnIndex, Object x) {
    }

    @Override
    public void updateNull(String columnLabel) {
    }

    @Override
    public void updateBoolean(String columnLabel, boolean x) {
    }

    @Override
    public void updateByte(String columnLabel, byte x) {
    }

    @Override
    public void updateShort(String columnLabel, short x) {
    }

    @Override
    public void updateInt(String columnLabel, int x) {
    }

    @Override
    public void updateLong(String columnLabel, long x) {
    }

    @Override
    public void updateFloat(String columnLabel, float x) {
    }

    @Override
    public void updateDouble(String columnLabel, double x) {
    }

    @Override
    public void updateBigDecimal(String columnLabel, BigDecimal x) {
    }

    @Override
    public void updateString(String columnLabel, String x) {
    }

    @Override
    public void updateBytes(String columnLabel, byte[] x) {
    }

    @Override
    public void updateDate(String columnLabel, Date x) {
    }

    @Override
    public void updateTime(String columnLabel, Time x) {
    }

    @Override
    public void updateTimestamp(String columnLabel, Timestamp x) {
    }

    @Override
    public void updateAsciiStream(String columnLabel, InputStream x, int length) {
    }

    @Override
    public void updateBinaryStream(String columnLabel, InputStream x, int length) {
    }

    @Override
    public void updateCharacterStream(String columnLabel, Reader reader, int length) {
    }

    @Override
    public void updateObject(String columnLabel, Object x, int scaleOrLength) {
    }

    @Override
    public void updateObject(String columnLabel, Object x) {
    }

    @Override
    public void insertRow() {
    }

    @Override
    public void updateRow() {
    }

    @Override
    public void deleteRow() {
    }

    @Override
    public void refreshRow() {
    }

    @Override
    public void cancelRowUpdates() {
    }

    @Override
    public void moveToInsertRow() {
    }

    @Override
    public void moveToCurrentRow() {
    }

    @Override
    public Statement getStatement() {
        return null;
    }

    @Override
    public Object getObject(int columnIndex, Map<String, Class<?>> map) throws SQLException {
        return getObject(columnIndex);
    }

    @Override
    public Ref getRef(int columnIndex) {
        return null;
    }

    @Override
    public Blob getBlob(int columnIndex) {
        return null;
    }

    @Override
    public Clob getClob(int columnIndex) {
        return null;
    }

    @Override
    public Array getArray(int columnIndex) {
        return null;
    }

    @Override
    public Object getObject(String columnLabel, Map<String, Class<?>> map) throws SQLException {
        return getObject(columnLabel);
    }

    @Override
    public Ref getRef(String columnLabel) {
        return null;
    }

    @Override
    public Blob getBlob(String columnLabel) {
        return null;
    }

    @Override
    public Clob getClob(String columnLabel) {
        return null;
    }

    @Override
    public Array getArray(String columnLabel) {
        return null;
    }

    @Override
    public Date getDate(int columnIndex, Calendar cal) {
        return null;
    }

    @Override
    public Date getDate(String columnLabel, Calendar cal) {
        return null;
    }

    @Override
    public Time getTime(int columnIndex, Calendar cal) {
        return null;
    }

    @Override
    public Time getTime(String columnLabel, Calendar cal) {
        return null;
    }

    @Override
    public Timestamp getTimestamp(int columnIndex, Calendar cal) {
        return null;
    }

    @Override
    public Timestamp getTimestamp(String columnLabel, Calendar cal) {
        return null;
    }

    @Override
    public URL getURL(int columnIndex) {
        return null;
    }

    @Override
    public URL getURL(String columnLabel) {
        return null;
    }

    @Override
    public void updateRef(int columnIndex, Ref x) {
    }

    @Override
    public void updateRef(String columnLabel, Ref x) {
    }

    @Override
    public void updateBlob(int columnIndex, Blob x) {
    }

    @Override
    public void updateBlob(String columnLabel, Blob x) {
    }

    @Override
    public void updateClob(int columnIndex, Clob x) {
    }

    @Override
    public void updateClob(String columnLabel, Clob x) {
    }

    @Override
    public void updateArray(int columnIndex, Array x) {
    }

    @Override
    public void updateArray(String columnLabel, Array x) {
    }

    @Override
    public RowId getRowId(int columnIndex) {
        return null;
    }

    @Override
    public RowId getRowId(String columnLabel) {
        return null;
    }

    @Override
    public void updateRowId(int columnIndex, RowId x) {
    }

    @Override
    public void updateRowId(String columnLabel, RowId x) {
    }

    @Override
    public int getHoldability() {
        return 0;
    }

    @Override
    public void updateNString(int columnIndex, String nString) {
    }

    @Override
    public void updateNString(String columnLabel, String nString) {
    }

    @Override
    public void updateNClob(int columnIndex, NClob nClob) {
    }

    @Override
    public void updateNClob(String columnLabel, NClob nClob) {
    }

    @Override
    public NClob getNClob(int columnIndex) {
        return null;
    }

    @Override
    public NClob getNClob(String columnLabel) {
        return null;
    }

    @Override
    public SQLXML getSQLXML(int columnIndex) {
        return null;
    }

    @Override
    public SQLXML getSQLXML(String columnLabel) {
        return null;
    }

    @Override
    public void updateSQLXML(int columnIndex, SQLXML xmlObject) {
    }

    @Override
    public void updateSQLXML(String columnLabel, SQLXML xmlObject) {
    }

    @Override
    public String getNString(int columnIndex) throws SQLException {
        return getString(columnIndex);
    }

    @Override
    public String getNString(String columnLabel) throws SQLException {
        return getString(columnLabel);
    }

    @Override
    public Reader getNCharacterStream(int columnIndex) {
        return null;
    }

    @Override
    public Reader getNCharacterStream(String columnLabel) {
        return null;
    }

    @Override
    public void updateNCharacterStream(int columnIndex, Reader x, long length) {
    }

    @Override
    public void updateNCharacterStream(String columnLabel, Reader reader, long length) {
    }

    @Override
    public void updateAsciiStream(int columnIndex, InputStream x, long length) {
    }

    @Override
    public void updateBinaryStream(int columnIndex, InputStream x, long length) {
    }

    @Override
    public void updateCharacterStream(int columnIndex, Reader x, long length) {
    }

    @Override
    public void updateAsciiStream(String columnLabel, InputStream x, long length) {
    }

    @Override
    public void updateBinaryStream(String columnLabel, InputStream x, long length) {
    }

    @Override
    public void updateCharacterStream(String columnLabel, Reader reader, long length) {
    }

    @Override
    public void updateBlob(int columnIndex, InputStream inputStream, long length) {
    }

    @Override
    public void updateBlob(String columnLabel, InputStream inputStream, long length) {
    }

    @Override
    public void updateClob(int columnIndex, Reader reader, long length) {
    }

    @Override
    public void updateClob(String columnLabel, Reader reader, long length) {
    }

    @Override
    public void updateNClob(int columnIndex, Reader reader, long length) {
    }

    @Override
    public void updateNClob(String columnLabel, Reader reader, long length) {
    }

    @Override
    public void updateNCharacterStream(int columnIndex, Reader x) {
    }

    @Override
    public void updateNCharacterStream(String columnLabel, Reader reader) {
    }

    @Override
    public void updateAsciiStream(int columnIndex, InputStream x) {
    }

    @Override
    public void updateBinaryStream(int columnIndex, InputStream x) {
    }

    @Override
    public void updateCharacterStream(int columnIndex, Reader x) {
    }

    @Override
    public void updateAsciiStream(String columnLabel, InputStream x) {
    }

    @Override
    public void updateBinaryStream(String columnLabel, InputStream x) {
    }

    @Override
    public void updateCharacterStream(String columnLabel, Reader reader) {
    }

    @Override
    public void updateBlob(int columnIndex, InputStream inputStream) {
    }

    @Override
    public void updateBlob(String columnLabel, InputStream inputStream) {
    }

    @Override
    public void updateClob(int columnIndex, Reader reader) {
    }

    @Override
    public void updateClob(String columnLabel, Reader reader) {
    }

    @Override
    public void updateNClob(int columnIndex, Reader reader) {
    }

    @Override
    public void updateNClob(String columnLabel, Reader reader) {
    }

    @Override
    public <T> T getObject(int columnIndex, Class<T> type) throws SQLException {
        throw new SQLException("Not supported");
    }

    @Override
    public <T> T getObject(String columnLabel, Class<T> type) throws SQLException {
        throw new SQLException("Not supported");
    }

    @Override
    public <T> T unwrap(Class<T> iface) throws SQLException {
        throw new SQLException("Not a wrapper");
    }

    @Override
    public boolean isWrapperFor(Class<?> iface) {
        return false;
    }
}
