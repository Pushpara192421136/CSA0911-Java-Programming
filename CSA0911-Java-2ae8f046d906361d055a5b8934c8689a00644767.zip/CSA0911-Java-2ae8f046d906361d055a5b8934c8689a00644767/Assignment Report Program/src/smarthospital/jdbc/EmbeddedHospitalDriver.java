package smarthospital.jdbc;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.DriverPropertyInfo;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.util.Properties;
import java.util.logging.Logger;

/**
 * Minimal JDBC driver so the assignment uses DriverManager / Connection / PreparedStatement
 * without requiring a third-party SQLite JAR. URL: jdbc:hospital:hospital.db
 */
public class EmbeddedHospitalDriver implements Driver {
    private static boolean registered = false;

    static {
        register();
    }

    public static synchronized void register() {
        if (registered) {
            return;
        }
        try {
            DriverManager.registerDriver(new EmbeddedHospitalDriver());
            registered = true;
        } catch (SQLException e) {
            throw new ExceptionInInitializerError(e);
        }
    }

    @Override
    public Connection connect(String url, Properties info) throws SQLException {
        if (!acceptsURL(url)) {
            return null;
        }
        String file = url.substring("jdbc:hospital:".length());
        return new EmbeddedConnection(file);
    }

    @Override
    public boolean acceptsURL(String url) {
        return url != null && url.startsWith("jdbc:hospital:");
    }

    @Override
    public DriverPropertyInfo[] getPropertyInfo(String url, Properties info) {
        return new DriverPropertyInfo[0];
    }

    @Override
    public int getMajorVersion() {
        return 1;
    }

    @Override
    public int getMinorVersion() {
        return 0;
    }

    @Override
    public boolean jdbcCompliant() {
        return false;
    }

    @Override
    public Logger getParentLogger() throws SQLFeatureNotSupportedException {
        throw new SQLFeatureNotSupportedException();
    }
}
