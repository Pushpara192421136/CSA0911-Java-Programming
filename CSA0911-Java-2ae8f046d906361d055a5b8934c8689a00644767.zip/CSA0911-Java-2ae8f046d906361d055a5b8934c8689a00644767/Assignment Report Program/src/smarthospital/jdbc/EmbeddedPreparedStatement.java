package smarthospital.jdbc;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.Date;
import java.sql.NClob;
import java.sql.ParameterMetaData;
import java.sql.PreparedStatement;
import java.sql.Ref;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.RowId;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.SQLXML;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

class EmbeddedPreparedStatement implements PreparedStatement {
    private final EmbeddedConnection connection;
    private final String sql;
    private final Map<Integer, String> params = new LinkedHashMap<Integer, String>();
    private boolean closed;

    EmbeddedPreparedStatement(EmbeddedConnection connection, String sql) {
        this.connection = connection;
        this.sql = sql == null ? "" : sql.trim();
    }

    @Override
    public void setString(int parameterIndex, String x) {
        params.put(Integer.valueOf(parameterIndex), x);
    }

    @Override
    public void setInt(int parameterIndex, int x) {
        params.put(Integer.valueOf(parameterIndex), String.valueOf(x));
    }

    @Override
    public void setDouble(int parameterIndex, double x) {
        params.put(Integer.valueOf(parameterIndex), String.valueOf(x));
    }

    @Override
    public void setObject(int parameterIndex, Object x) {
        params.put(Integer.valueOf(parameterIndex), x == null ? "" : String.valueOf(x));
    }

    @Override
    public int executeUpdate() throws SQLException {
        String normalized = sql.replaceAll("\\s+", " ").trim();
        String upper = normalized.toUpperCase(Locale.ROOT);
        Map<String, List<Map<String, String>>> tables = connection.tables();
        if (upper.startsWith("CREATE TABLE")) {
            String name = extractTableName(normalized, "CREATE TABLE");
            if (!tables.containsKey(name)) {
                tables.put(name, new ArrayList<Map<String, String>>());
            }
            connection.persist();
            return 0;
        }
        if (upper.startsWith("INSERT INTO")) {
            String table = extractTableName(normalized, "INSERT INTO");
            List<String> columns = extractColumnList(normalized);
            List<Map<String, String>> rows = table(tables, table);
            Map<String, String> row = new LinkedHashMap<String, String>();
            for (int i = 0; i < columns.size(); i++) {
                row.put(columns.get(i), params.get(Integer.valueOf(i + 1)));
            }
            rows.add(row);
            connection.persist();
            return 1;
        }
        if (upper.startsWith("UPDATE")) {
            String table = extractTableName(normalized, "UPDATE");
            String setCol = extractBetween(normalized, "SET ", " =");
            String whereCol = extractAfter(normalized, "WHERE ");
            whereCol = whereCol.replace("= ?", "").replace("=?", "").trim();
            String newVal = params.get(Integer.valueOf(1));
            String whereVal = params.get(Integer.valueOf(2));
            int count = 0;
            for (Map<String, String> row : table(tables, table)) {
                if (whereVal != null && whereVal.equals(row.get(whereCol))) {
                    row.put(setCol, newVal);
                    count++;
                }
            }
            connection.persist();
            return count;
        }
        if (upper.startsWith("DELETE FROM")) {
            String table = extractTableName(normalized, "DELETE FROM");
            String whereColRaw = extractAfter(normalized, "WHERE ");
            final String whereCol = whereColRaw.replace("= ?", "").replace("=?", "").trim();
            final String whereVal = params.get(Integer.valueOf(1));
            List<Map<String, String>> rows = table(tables, table);
            int before = rows.size();
            rows.removeIf(row -> whereVal != null && whereVal.equals(row.get(whereCol)));
            connection.persist();
            return before - rows.size();
        }
        throw new SQLException("Unsupported SQL: " + sql);
    }

    @Override
    public ResultSet executeQuery() throws SQLException {
        String normalized = sql.replaceAll("\\s+", " ").trim();
        String upper = normalized.toUpperCase(Locale.ROOT);
        Map<String, List<Map<String, String>>> tables = connection.tables();
        if (!upper.startsWith("SELECT")) {
            throw new SQLException("Not a query: " + sql);
        }
        String table;
        List<Map<String, String>> source;
        if (upper.contains(" WHERE ")) {
            table = extractTableName(normalized, "FROM");
            String whereCol = extractAfter(normalized, "WHERE ");
            whereCol = whereCol.replace("= ?", "").replace("=?", "").trim();
            String whereVal = params.get(Integer.valueOf(1));
            source = new ArrayList<Map<String, String>>();
            for (Map<String, String> row : table(tables, table)) {
                if (whereVal != null && whereVal.equals(row.get(whereCol))) {
                    source.add(new LinkedHashMap<String, String>(row));
                }
            }
        } else {
            table = extractTableName(normalized, "FROM");
            source = new ArrayList<Map<String, String>>();
            for (Map<String, String> row : table(tables, table)) {
                source.add(new LinkedHashMap<String, String>(row));
            }
        }
        return new EmbeddedResultSet(source);
    }

    @Override
    public boolean execute() throws SQLException {
        String upper = sql.toUpperCase(Locale.ROOT);
        if (upper.startsWith("SELECT")) {
            return true;
        }
        executeUpdate();
        return false;
    }

    private List<Map<String, String>> table(Map<String, List<Map<String, String>>> tables, String name)
            throws SQLException {
        List<Map<String, String>> rows = tables.get(name);
        if (rows == null) {
            rows = new ArrayList<Map<String, String>>();
            tables.put(name, rows);
        }
        return rows;
    }

    private static String extractTableName(String sql, String keyword) {
        String upper = sql.toUpperCase(Locale.ROOT);
        String key = keyword.toUpperCase(Locale.ROOT);
        int idx = upper.indexOf(key);
        String rest = sql.substring(idx + keyword.length()).trim();
        if (rest.toUpperCase(Locale.ROOT).startsWith("IF NOT EXISTS")) {
            rest = rest.substring("IF NOT EXISTS".length()).trim();
        }
        String name = rest.split("[\\s(]")[0];
        return name.toLowerCase(Locale.ROOT);
    }

    private static List<String> extractColumnList(String sql) {
        int open = sql.indexOf('(');
        int close = sql.indexOf(')', open);
        String inside = sql.substring(open + 1, close);
        String[] parts = inside.split(",");
        List<String> cols = new ArrayList<String>();
        for (String part : parts) {
            cols.add(part.trim().toLowerCase(Locale.ROOT));
        }
        return cols;
    }

    private static String extractBetween(String sql, String start, String end) {
        String upper = sql.toUpperCase(Locale.ROOT);
        int s = upper.indexOf(start.toUpperCase(Locale.ROOT));
        String rest = sql.substring(s + start.length());
        int e = rest.toUpperCase(Locale.ROOT).indexOf(end.toUpperCase(Locale.ROOT));
        return rest.substring(0, e).trim().toLowerCase(Locale.ROOT);
    }

    private static String extractAfter(String sql, String start) {
        String upper = sql.toUpperCase(Locale.ROOT);
        int s = upper.indexOf(start.toUpperCase(Locale.ROOT));
        return sql.substring(s + start.length()).trim();
    }

    @Override
    public void close() {
        closed = true;
    }

    @Override
    public boolean isClosed() {
        return closed;
    }

    @Override
    public ResultSet executeQuery(String sql) throws SQLException {
        throw new SQLException("Use executeQuery() on PreparedStatement");
    }

    @Override
    public int executeUpdate(String sql) throws SQLException {
        throw new SQLException("Use executeUpdate() on PreparedStatement");
    }

    @Override
    public boolean execute(String sql) throws SQLException {
        throw new SQLException("Use execute() on PreparedStatement");
    }

    @Override
    public void setNull(int parameterIndex, int sqlType) {
        params.put(Integer.valueOf(parameterIndex), "");
    }

    @Override
    public void setBoolean(int parameterIndex, boolean x) {
        setString(parameterIndex, String.valueOf(x));
    }

    @Override
    public void setByte(int parameterIndex, byte x) {
        setInt(parameterIndex, x);
    }

    @Override
    public void setShort(int parameterIndex, short x) {
        setInt(parameterIndex, x);
    }

    @Override
    public void setLong(int parameterIndex, long x) {
        setString(parameterIndex, String.valueOf(x));
    }

    @Override
    public void setFloat(int parameterIndex, float x) {
        setDouble(parameterIndex, x);
    }

    @Override
    public void setBigDecimal(int parameterIndex, BigDecimal x) {
        setString(parameterIndex, x == null ? "" : x.toPlainString());
    }

    @Override
    public void setBytes(int parameterIndex, byte[] x) {
        setString(parameterIndex, x == null ? "" : new String(x));
    }

    @Override
    public void setDate(int parameterIndex, Date x) {
        setString(parameterIndex, x == null ? "" : x.toString());
    }

    @Override
    public void setTime(int parameterIndex, Time x) {
        setString(parameterIndex, x == null ? "" : x.toString());
    }

    @Override
    public void setTimestamp(int parameterIndex, Timestamp x) {
        setString(parameterIndex, x == null ? "" : x.toString());
    }

    @Override
    public void setAsciiStream(int parameterIndex, InputStream x, int length) throws SQLException {
        throw new SQLException("Not supported");
    }

    @Override
    public void setUnicodeStream(int parameterIndex, InputStream x, int length) throws SQLException {
        throw new SQLException("Not supported");
    }

    @Override
    public void setBinaryStream(int parameterIndex, InputStream x, int length) throws SQLException {
        throw new SQLException("Not supported");
    }

    @Override
    public void clearParameters() {
        params.clear();
    }

    @Override
    public void setRef(int parameterIndex, Ref x) throws SQLException {
        throw new SQLException("Not supported");
    }

    @Override
    public void setBlob(int parameterIndex, Blob x) throws SQLException {
        throw new SQLException("Not supported");
    }

    @Override
    public void setClob(int parameterIndex, Clob x) throws SQLException {
        throw new SQLException("Not supported");
    }

    @Override
    public void setArray(int parameterIndex, Array x) throws SQLException {
        throw new SQLException("Not supported");
    }

    @Override
    public ResultSetMetaData getMetaData() {
        return null;
    }

    @Override
    public void setDate(int parameterIndex, Date x, Calendar cal) {
        setDate(parameterIndex, x);
    }

    @Override
    public void setTime(int parameterIndex, Time x, Calendar cal) {
        setTime(parameterIndex, x);
    }

    @Override
    public void setTimestamp(int parameterIndex, Timestamp x, Calendar cal) {
        setTimestamp(parameterIndex, x);
    }

    @Override
    public void setNull(int parameterIndex, int sqlType, String typeName) {
        setNull(parameterIndex, sqlType);
    }

    @Override
    public void setURL(int parameterIndex, URL x) {
        setString(parameterIndex, x == null ? "" : x.toString());
    }

    @Override
    public ParameterMetaData getParameterMetaData() {
        return null;
    }

    @Override
    public void setRowId(int parameterIndex, RowId x) throws SQLException {
        throw new SQLException("Not supported");
    }

    @Override
    public void setNString(int parameterIndex, String value) {
        setString(parameterIndex, value);
    }

    @Override
    public void setNCharacterStream(int parameterIndex, Reader value, long length) throws SQLException {
        throw new SQLException("Not supported");
    }

    @Override
    public void setNClob(int parameterIndex, NClob value) throws SQLException {
        throw new SQLException("Not supported");
    }

    @Override
    public void setClob(int parameterIndex, Reader reader, long length) throws SQLException {
        throw new SQLException("Not supported");
    }

    @Override
    public void setBlob(int parameterIndex, InputStream inputStream, long length) throws SQLException {
        throw new SQLException("Not supported");
    }

    @Override
    public void setNClob(int parameterIndex, Reader reader, long length) throws SQLException {
        throw new SQLException("Not supported");
    }

    @Override
    public void setSQLXML(int parameterIndex, SQLXML xmlObject) throws SQLException {
        throw new SQLException("Not supported");
    }

    @Override
    public void setObject(int parameterIndex, Object x, int targetSqlType) {
        setObject(parameterIndex, x);
    }

    @Override
    public void setObject(int parameterIndex, Object x, int targetSqlType, int scaleOrLength) {
        setObject(parameterIndex, x);
    }

    @Override
    public void setAsciiStream(int parameterIndex, InputStream x, long length) throws SQLException {
        throw new SQLException("Not supported");
    }

    @Override
    public void setBinaryStream(int parameterIndex, InputStream x, long length) throws SQLException {
        throw new SQLException("Not supported");
    }

    @Override
    public void setCharacterStream(int parameterIndex, Reader reader, long length) throws SQLException {
        throw new SQLException("Not supported");
    }

    @Override
    public void setAsciiStream(int parameterIndex, InputStream x) throws SQLException {
        throw new SQLException("Not supported");
    }

    @Override
    public void setBinaryStream(int parameterIndex, InputStream x) throws SQLException {
        throw new SQLException("Not supported");
    }

    @Override
    public void setCharacterStream(int parameterIndex, Reader reader) throws SQLException {
        throw new SQLException("Not supported");
    }

    @Override
    public void setNCharacterStream(int parameterIndex, Reader value) throws SQLException {
        throw new SQLException("Not supported");
    }

    @Override
    public void setClob(int parameterIndex, Reader reader) throws SQLException {
        throw new SQLException("Not supported");
    }

    @Override
    public void setBlob(int parameterIndex, InputStream inputStream) throws SQLException {
        throw new SQLException("Not supported");
    }

    @Override
    public void setNClob(int parameterIndex, Reader reader) throws SQLException {
        throw new SQLException("Not supported");
    }

    @Override
    public void setCharacterStream(int parameterIndex, Reader reader, int length) throws SQLException {
        throw new SQLException("Not supported");
    }

    @Override
    public int getMaxFieldSize() {
        return 0;
    }

    @Override
    public void setMaxFieldSize(int max) {
    }

    @Override
    public int getMaxRows() {
        return 0;
    }

    @Override
    public void setMaxRows(int max) {
    }

    @Override
    public void setEscapeProcessing(boolean enable) {
    }

    @Override
    public int getQueryTimeout() {
        return 0;
    }

    @Override
    public void setQueryTimeout(int seconds) {
    }

    @Override
    public void cancel() {
    }

    @Override
    public SQLWarning getWarnings() {
        return null;
    }

    @Override
    public void clearWarnings() {
    }

    @Override
    public void setCursorName(String name) {
    }

    @Override
    public ResultSet getResultSet() {
        return null;
    }

    @Override
    public int getUpdateCount() {
        return -1;
    }

    @Override
    public boolean getMoreResults() {
        return false;
    }

    @Override
    public void setFetchDirection(int direction) {
    }

    @Override
    public int getFetchDirection() {
        return ResultSet.FETCH_FORWARD;
    }

    @Override
    public void setFetchSize(int rows) {
    }

    @Override
    public int getFetchSize() {
        return 0;
    }

    @Override
    public int getResultSetConcurrency() {
        return ResultSet.CONCUR_READ_ONLY;
    }

    @Override
    public int getResultSetType() {
        return ResultSet.TYPE_FORWARD_ONLY;
    }

    @Override
    public void addBatch(String sql) {
    }

    @Override
    public void clearBatch() {
    }

    @Override
    public int[] executeBatch() {
        return new int[0];
    }

    @Override
    public Connection getConnection() {
        return connection;
    }

    @Override
    public boolean getMoreResults(int current) {
        return false;
    }

    @Override
    public ResultSet getGeneratedKeys() {
        return null;
    }

    @Override
    public int executeUpdate(String sql, int autoGeneratedKeys) throws SQLException {
        throw new SQLException("Not supported");
    }

    @Override
    public int executeUpdate(String sql, int[] columnIndexes) throws SQLException {
        throw new SQLException("Not supported");
    }

    @Override
    public int executeUpdate(String sql, String[] columnNames) throws SQLException {
        throw new SQLException("Not supported");
    }

    @Override
    public boolean execute(String sql, int autoGeneratedKeys) throws SQLException {
        throw new SQLException("Not supported");
    }

    @Override
    public boolean execute(String sql, int[] columnIndexes) throws SQLException {
        throw new SQLException("Not supported");
    }

    @Override
    public boolean execute(String sql, String[] columnNames) throws SQLException {
        throw new SQLException("Not supported");
    }

    @Override
    public int getResultSetHoldability() {
        return 0;
    }

    @Override
    public void setPoolable(boolean poolable) {
    }

    @Override
    public boolean isPoolable() {
        return false;
    }

    @Override
    public void closeOnCompletion() {
    }

    @Override
    public boolean isCloseOnCompletion() {
        return false;
    }

    @Override
    public void addBatch() {
    }

    @Override
    public <T> T unwrap(Class<T> iface) throws SQLException {
        throw new SQLException("Not a wrapper");
    }

    @Override
    public boolean isWrapperFor(Class<?> iface) {
        return false;
    }
}
