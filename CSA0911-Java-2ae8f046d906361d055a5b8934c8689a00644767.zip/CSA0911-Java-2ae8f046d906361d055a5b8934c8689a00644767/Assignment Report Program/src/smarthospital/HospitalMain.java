package smarthospital;

import smarthospital.ui.AppletViewer;
import smarthospital.ui.ConsoleApp;

/**
 * Entry point: console menu (default) or applet GUI with --applet
 */
public class HospitalMain {
    public static void main(String[] args) {
        if (args != null && args.length > 0 && "--applet".equalsIgnoreCase(args[0])) {
            AppletViewer.launch();
            return;
        }
        new ConsoleApp().run();
    }
}
