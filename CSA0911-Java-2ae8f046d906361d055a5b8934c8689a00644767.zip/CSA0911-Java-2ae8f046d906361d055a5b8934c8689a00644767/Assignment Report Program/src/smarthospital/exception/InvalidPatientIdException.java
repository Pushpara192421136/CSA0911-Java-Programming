package smarthospital.exception;

public class InvalidPatientIdException extends Exception {
    public InvalidPatientIdException(String patientId) {
        super("Invalid or unknown patient ID: " + patientId);
    }
}
