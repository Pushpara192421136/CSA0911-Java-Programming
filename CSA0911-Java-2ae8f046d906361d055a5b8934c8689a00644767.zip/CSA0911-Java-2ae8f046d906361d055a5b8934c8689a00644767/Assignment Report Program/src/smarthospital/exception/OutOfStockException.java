package smarthospital.exception;

public class OutOfStockException extends Exception {
    public OutOfStockException(String medicineName) {
        super("Medicine out of stock: " + medicineName);
    }
}
