package smarthospital.exception;

public class DoctorFullyBookedException extends Exception {
    public DoctorFullyBookedException(String doctorId) {
        super("Doctor " + doctorId + " has no free slots. Patient added to waitlist.");
    }
}
