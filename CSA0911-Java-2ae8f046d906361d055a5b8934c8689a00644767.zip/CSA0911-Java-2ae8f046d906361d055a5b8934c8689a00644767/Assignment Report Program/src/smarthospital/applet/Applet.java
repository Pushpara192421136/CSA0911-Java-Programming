package smarthospital.applet;

import java.awt.Panel;

/**
 * Classic Applet lifecycle on AWT. java.applet.Applet was removed from the JDK after Java 8,
 * so this assignment-friendly base class preserves init/start/stop/destroy on modern JDKs.
 */
public class Applet extends Panel {
    private static final long serialVersionUID = 1L;

    public void init() {
    }

    public void start() {
    }

    public void stop() {
    }

    public void destroy() {
    }

    public String getParameter(String name) {
        return null;
    }
}
