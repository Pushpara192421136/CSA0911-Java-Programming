package smarthospital.ui;

import smarthospital.applet.Applet;
import smarthospital.exception.DoctorFullyBookedException;
import smarthospital.exception.DuplicateAppointmentException;
import smarthospital.exception.InvalidInputException;
import smarthospital.exception.InvalidPatientIdException;
import smarthospital.exception.OutOfStockException;
import smarthospital.model.Doctor;
import smarthospital.model.Medicine;
import smarthospital.model.Patient;
import smarthospital.service.HospitalService;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Choice;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Hospital GUI implemented as an Applet (init/start/stop/destroy) using AWT widgets.
 */
public class HospitalApplet extends Applet implements ActionListener {
    private static final long serialVersionUID = 1L;

    private final HospitalService service = HospitalService.getInstance();
    private TextField nameField;
    private TextField ageField;
    private TextField phoneField;
    private Choice categoryChoice;
    private TextField patientIdField;
    private TextField doctorIdField;
    private TextField slotField;
    private TextField medicineIdField;
    private TextField qtyField;
    private TextArea output;
    private Label status;

    @Override
    public void init() {
        setLayout(new BorderLayout(8, 8));
        setBackground(new Color(235, 245, 250));

        Label title = new Label("Smart Hospital Appointment, Pharmacy and Alerts (Applet)", Label.CENTER);
        title.setFont(new Font("SansSerif", Font.BOLD, 16));
        add(title, BorderLayout.NORTH);

        Panel form = new Panel(new GridLayout(0, 2, 6, 4));
        nameField = new TextField();
        ageField = new TextField();
        phoneField = new TextField();
        categoryChoice = new Choice();
        categoryChoice.add("REGULAR");
        categoryChoice.add("SENIOR");
        categoryChoice.add("PEDIATRIC");
        patientIdField = new TextField();
        doctorIdField = new TextField();
        slotField = new TextField("09:00");
        medicineIdField = new TextField();
        qtyField = new TextField("1");

        form.add(new Label("Patient name"));
        form.add(nameField);
        form.add(new Label("Age"));
        form.add(ageField);
        form.add(new Label("Phone"));
        form.add(phoneField);
        form.add(new Label("Category"));
        form.add(categoryChoice);
        form.add(new Label("Patient ID"));
        form.add(patientIdField);
        form.add(new Label("Doctor ID"));
        form.add(doctorIdField);
        form.add(new Label("Preferred slot"));
        form.add(slotField);
        form.add(new Label("Medicine ID"));
        form.add(medicineIdField);
        form.add(new Label("Dispense qty"));
        form.add(qtyField);
        add(form, BorderLayout.WEST);

        Panel buttons = new Panel(new GridLayout(0, 2, 6, 6));
        addButton(buttons, "Register Patient");
        addButton(buttons, "Book Appointment");
        addButton(buttons, "Cancel Appointment");
        addButton(buttons, "Show Slots");
        addButton(buttons, "Show Stock");
        addButton(buttons, "Dispense Medicine");
        addButton(buttons, "Visit Report");
        addButton(buttons, "Inventory Report");
        addButton(buttons, "List Patients");
        addButton(buttons, "List Doctors");
        add(buttons, BorderLayout.CENTER);

        output = new TextArea("", 18, 70, TextArea.SCROLLBARS_BOTH);
        output.setEditable(false);
        add(output, BorderLayout.SOUTH);

        status = new Label("Applet init complete. JDBC store: hospital.db");
        add(status, BorderLayout.EAST);
    }

    private void addButton(Panel parent, String label) {
        Button b = new Button(label);
        b.addActionListener(this);
        parent.add(b);
    }

    @Override
    public void start() {
        status.setText("Applet started");
        showText(service.availableSlotsReport() + "\n" + service.stockReport());
    }

    @Override
    public void stop() {
        status.setText("Applet stopped");
    }

    @Override
    public void destroy() {
        status.setText("Applet destroyed");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String cmd = e.getActionCommand();
        try {
            if ("Register Patient".equals(cmd)) {
                int age = Integer.parseInt(ageField.getText().trim());
                Patient p = service.registerPatient(
                        nameField.getText(), age, phoneField.getText(), categoryChoice.getSelectedItem());
                patientIdField.setText(p.getPatientId());
                showText("Registered: " + p + "\nFee after waiver Rs." + p.getConsultationFee(HospitalService.BASE_CONSULTATION_FEE));
            } else if ("Book Appointment".equals(cmd)) {
                String result = service.bookAppointment(
                        patientIdField.getText().trim(),
                        doctorIdField.getText().trim(),
                        slotField.getText().trim());
                showText(result);
            } else if ("Cancel Appointment".equals(cmd)) {
                showText("Put appointment ID in the Patient ID field, then click Cancel.\n"
                        + service.cancelAppointment(patientIdField.getText().trim()));
            } else if ("Show Slots".equals(cmd)) {
                showText(service.availableSlotsReport());
            } else if ("Show Stock".equals(cmd)) {
                showText(service.stockReport());
            } else if ("Dispense Medicine".equals(cmd)) {
                int qty = Integer.parseInt(qtyField.getText().trim());
                showText(service.dispenseMedicine(medicineIdField.getText().trim(), qty));
            } else if ("Visit Report".equals(cmd)) {
                showText(service.patientVisitReport());
            } else if ("Inventory Report".equals(cmd)) {
                showText(service.pharmacyUtilizationReport());
            } else if ("List Patients".equals(cmd)) {
                StringBuilder sb = new StringBuilder();
                for (Patient p : service.getPatients()) {
                    sb.append(p).append('\n');
                }
                showText(sb.toString());
            } else if ("List Doctors".equals(cmd)) {
                StringBuilder sb = new StringBuilder();
                for (Doctor d : service.getDoctors()) {
                    sb.append(d).append('\n');
                }
                for (Medicine m : service.getMedicines()) {
                    sb.append(m).append('\n');
                }
                showText(sb.toString());
            }
        } catch (NumberFormatException ex) {
            showText("Invalid number: " + ex.getMessage());
        } catch (InvalidPatientIdException | DuplicateAppointmentException | DoctorFullyBookedException
                 | InvalidInputException | OutOfStockException ex) {
            showText(ex.getMessage());
        } catch (Exception ex) {
            showText("Error: " + ex.getMessage());
        }
    }

    private void showText(String text) {
        output.setText(text);
        status.setText("Last action completed");
    }
}
