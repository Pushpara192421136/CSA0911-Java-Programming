package smarthospital.ui;

import java.awt.BorderLayout;
import java.awt.Frame;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 * Launches HospitalApplet inside a Frame, invoking the Applet lifecycle methods.
 */
public class AppletViewer {
    public static void launch() {
        final HospitalApplet applet = new HospitalApplet();
        Frame frame = new Frame("Smart Hospital Applet Viewer");
        frame.setLayout(new BorderLayout());
        frame.add(applet, BorderLayout.CENTER);
        frame.setSize(1100, 720);
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                applet.stop();
                applet.destroy();
                frame.dispose();
            }
        });
        frame.setVisible(true);
        applet.init();
        applet.start();
        frame.validate();
    }
}
