package smarthospital.ui;

import smarthospital.concurrent.AppointmentBookingTask;
import smarthospital.exception.DoctorFullyBookedException;
import smarthospital.exception.DuplicateAppointmentException;
import smarthospital.exception.InvalidInputException;
import smarthospital.exception.InvalidPatientIdException;
import smarthospital.exception.OutOfStockException;
import smarthospital.model.Appointment;
import smarthospital.model.Doctor;
import smarthospital.model.Medicine;
import smarthospital.model.Patient;
import smarthospital.service.HospitalService;

import java.util.Scanner;

/**
 * Menu-driven console interface required by the assignment problem statement.
 */
public class ConsoleApp {
    private final HospitalService service = HospitalService.getInstance();
    private final Scanner scanner = new Scanner(System.in);

    public void run() {
        boolean running = true;
        while (running) {
            printMenu();
            String choice = scanner.nextLine().trim();
            try {
                switch (choice) {
                    case "1":
                        registerPatient();
                        break;
                    case "2":
                        registerDoctor();
                        break;
                    case "3":
                        addMedicine();
                        break;
                    case "4":
                        System.out.println(service.availableSlotsReport());
                        break;
                    case "5":
                        System.out.println(service.stockReport());
                        break;
                    case "6":
                        bookAppointment();
                        break;
                    case "7":
                        cancelAppointment();
                        break;
                    case "8":
                        searchPatient();
                        break;
                    case "9":
                        updatePatient();
                        break;
                    case "10":
                        updateMedicine();
                        break;
                    case "11":
                        System.out.println(service.waitlistReport());
                        break;
                    case "12":
                        dispense();
                        break;
                    case "13":
                        concurrentDemo();
                        break;
                    case "14":
                        System.out.println(service.patientVisitReport());
                        break;
                    case "15":
                        System.out.println(service.pharmacyUtilizationReport());
                        break;
                    case "16":
                        listAll();
                        break;
                    case "17":
                        AppletViewer.launch();
                        System.out.println("Applet window opened.");
                        break;
                    case "0":
                        running = false;
                        service.shutdown();
                        System.out.println("Goodbye.");
                        break;
                    default:
                        System.out.println("Unknown option. Enter 0-17.");
                }
            } catch (InvalidPatientIdException | DuplicateAppointmentException | DoctorFullyBookedException
                     | InvalidInputException | OutOfStockException ex) {
                System.out.println("Business error: " + ex.getMessage());
            } catch (NumberFormatException ex) {
                System.out.println("Invalid numeric input. Please try again.");
            } catch (Exception ex) {
                System.out.println("Unexpected error: " + ex.getMessage());
            } finally {
                if (running) {
                    System.out.println();
                }
            }
        }
    }

    private void printMenu() {
        System.out.println("====================================================");
        System.out.println(" Smart Hospital Appointment, Pharmacy & Alerts");
        System.out.println(" JDBC URL: " + smarthospital.dao.DatabaseManager.JDBC_URL);
        System.out.println("====================================================");
        System.out.println(" 1. Register patient");
        System.out.println(" 2. Register doctor");
        System.out.println(" 3. Add medicine");
        System.out.println(" 4. Display available appointment slots");
        System.out.println(" 5. Display medicine stock");
        System.out.println(" 6. Book appointment");
        System.out.println(" 7. Cancel appointment");
        System.out.println(" 8. Search patient");
        System.out.println(" 9. Update patient");
        System.out.println("10. Search / update medicine");
        System.out.println("11. View waitlist");
        System.out.println("12. Prescribe / dispense medicine");
        System.out.println("13. Concurrent booking demo (threads)");
        System.out.println("14. Patient-visit report");
        System.out.println("15. Pharmacy inventory report");
        System.out.println("16. List patients, doctors, medicines, appointments");
        System.out.println("17. Launch Applet GUI");
        System.out.println(" 0. Exit");
        System.out.print("Enter choice: ");
    }

    private void registerPatient() throws Exception {
        System.out.print("Name: ");
        String name = scanner.nextLine();
        System.out.print("Age: ");
        int age = Integer.parseInt(scanner.nextLine().trim());
        System.out.print("Phone: ");
        String phone = scanner.nextLine();
        System.out.print("Category [REGULAR/SENIOR/PEDIATRIC]: ");
        String cat = scanner.nextLine();
        Patient p = service.registerPatient(name, age, phone, cat);
        System.out.println("Saved via JDBC: " + p);
        System.out.println("Consultation fee Rs." + p.getConsultationFee(HospitalService.BASE_CONSULTATION_FEE));
    }

    private void registerDoctor() throws Exception {
        System.out.print("Name: ");
        String name = scanner.nextLine();
        System.out.print("Specialization: ");
        String spec = scanner.nextLine();
        System.out.print("Slots per day (1-8): ");
        int slots = Integer.parseInt(scanner.nextLine().trim());
        System.out.println("Saved via JDBC: " + service.registerDoctor(name, spec, slots));
    }

    private void addMedicine() throws Exception {
        System.out.print("Name: ");
        String name = scanner.nextLine();
        System.out.print("Type [TABLET/SYRUP]: ");
        String type = scanner.nextLine();
        System.out.print("Stock: ");
        int stock = Integer.parseInt(scanner.nextLine().trim());
        System.out.print("Reorder level: ");
        int reorder = Integer.parseInt(scanner.nextLine().trim());
        System.out.print("Unit price: ");
        double price = Double.parseDouble(scanner.nextLine().trim());
        System.out.println("Saved via JDBC: " + service.addMedicine(name, type, stock, reorder, price));
    }

    private void bookAppointment() throws Exception {
        System.out.print("Patient ID: ");
        String pid = scanner.nextLine().trim();
        System.out.print("Doctor ID: ");
        String did = scanner.nextLine().trim();
        System.out.print("Preferred slot (or blank for first free): ");
        String slot = scanner.nextLine().trim();
        System.out.println(service.bookAppointment(pid, did, slot));
    }

    private void cancelAppointment() throws Exception {
        System.out.print("Appointment ID: ");
        String aid = scanner.nextLine().trim();
        System.out.println(service.cancelAppointment(aid));
    }

    private void searchPatient() throws Exception {
        System.out.print("Patient ID: ");
        String id = scanner.nextLine().trim();
        Patient p = service.requirePatient(id);
        System.out.println(p);
        System.out.println("Fee Rs." + p.getConsultationFee(HospitalService.BASE_CONSULTATION_FEE));
    }

    private void updatePatient() throws Exception {
        System.out.print("Patient ID: ");
        String id = scanner.nextLine().trim();
        System.out.print("New name (blank=keep): ");
        String name = scanner.nextLine();
        System.out.print("New phone (blank=keep): ");
        String phone = scanner.nextLine();
        System.out.print("New age (blank=keep): ");
        String ageText = scanner.nextLine().trim();
        Integer age = ageText.isEmpty() ? null : Integer.valueOf(ageText);
        System.out.println("Updated: " + service.updatePatient(id, emptyToNull(name), emptyToNull(phone), age));
    }

    private void updateMedicine() throws Exception {
        System.out.print("Medicine ID: ");
        String id = scanner.nextLine().trim();
        Medicine found = null;
        for (Medicine m : service.getMedicines()) {
            if (m.getMedicineId().equals(id)) {
                found = m;
                break;
            }
        }
        if (found == null) {
            throw new InvalidInputException("Unknown medicine ID: " + id);
        }
        System.out.println("Current: " + found);
        System.out.print("New name (blank=keep): ");
        String name = scanner.nextLine();
        System.out.print("New stock (blank=keep): ");
        String stockText = scanner.nextLine().trim();
        Integer stock = stockText.isEmpty() ? null : Integer.valueOf(stockText);
        System.out.println("Updated: " + service.updateMedicine(id, emptyToNull(name), stock));
    }

    private void dispense() throws Exception {
        System.out.print("Medicine ID: ");
        String id = scanner.nextLine().trim();
        System.out.print("Quantity: ");
        int qty = Integer.parseInt(scanner.nextLine().trim());
        System.out.println(service.dispenseMedicine(id, qty));
    }

    private void concurrentDemo() throws InterruptedException {
        System.out.println("Starting two high-priority booking threads against the same doctor...");
        if (service.getPatients().size() < 2 || service.getDoctors().isEmpty()) {
            System.out.println("Need at least two patients and one doctor.");
            return;
        }
        String p1 = service.getPatients().get(0).getPatientId();
        String p2 = service.getPatients().get(1).getPatientId();
        String d = service.getDoctors().get(0).getDoctorId();
        AppointmentBookingTask t1 = new AppointmentBookingTask(service, p1, d, "09:00");
        AppointmentBookingTask t2 = new AppointmentBookingTask(service, p2, d, "09:00");
        t1.start();
        t2.start();
        t1.join();
        t2.join();
        System.out.println("Thread-1 (" + t1.getName() + " pri=" + t1.getPriority() + "): " + t1.getOutcome());
        System.out.println("Thread-2 (" + t2.getName() + " pri=" + t2.getPriority() + "): " + t2.getOutcome());
        Thread.sleep(400);
        System.out.println(service.availableSlotsReport());
    }

    private void listAll() {
        System.out.println("-- Patients --");
        for (Patient p : service.getPatients()) {
            System.out.println(p);
        }
        System.out.println("-- Doctors --");
        for (Doctor d : service.getDoctors()) {
            System.out.println(d);
        }
        System.out.println("-- Medicines --");
        for (Medicine m : service.getMedicines()) {
            System.out.println(m);
        }
        System.out.println("-- Appointments --");
        for (Appointment a : service.getAppointments()) {
            System.out.println(a);
        }
    }

    private String emptyToNull(String s) {
        if (s == null || s.trim().isEmpty()) {
            return null;
        }
        return s;
    }
}
