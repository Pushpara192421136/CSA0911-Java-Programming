import docx
from docx.shared import Pt, Inches
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT

def add_heading(doc, text, level=1):
    heading = doc.add_heading(text, level=level)
    for run in heading.runs:
        run.font.name = 'Arial'

def add_paragraph(doc, text):
    p = doc.add_paragraph(text)
    p.style.font.name = 'Arial'
    p.style.font.size = Pt(11)
    return p

def main():
    doc = docx.Document()
    
    # Title
    title = doc.add_heading('COMMON COURSE ASSIGNMENT FORMAT', 0)
    title.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
    
    add_heading(doc, 'A. Assignment Information', level=1)
    table = doc.add_table(rows=11, cols=2)
    table.style = 'Table Grid'
    records = [
        ("Department:", "[Enter Department]"),
        ("Programme:", "[Enter Programme]"),
        ("Course Code & Name:", "CSA09 – Programming in Java (SLOT B)"),
        ("Academic Year / Batch:", "[Enter Academic Year / Batch]"),
        ("Faculty Name:", "[Enter Faculty Name]"),
        ("Assignment Title:", "Smart Hospital Patient Appointment, Pharmacy Inventory and Alert Notification System using Java"),
        ("Date of Issue:", "[Enter Date]"),
        ("Date of Submission:", "[Enter Date]"),
        ("Course Outcome(s) – CO:", "CO1, CO2, CO3"),
        ("Bloom's Taxonomy Level:", "L2 – Understand; L3 – Apply; L4 – Analyse"),
        ("SDG Mapping (SDG 1-17):", "SDG 3, SDG 9, SDG 10")
    ]
    for i, (k, v) in enumerate(records):
        table.cell(i, 0).text = k
        table.cell(i, 1).text = v

    add_heading(doc, 'B. Personal Details', level=1)
    add_paragraph(doc, "Team Member 1: [Name] - [Reg No]")
    add_paragraph(doc, "Team Member 2: [Name] - [Reg No]")
    add_paragraph(doc, "Team Member 3: [Name] - [Reg No]")
    add_paragraph(doc, "Team Member 4: [Name] - [Reg No]")
    add_paragraph(doc, "Team Member 5: [Name] - [Reg No]")

    add_heading(doc, '1. Problem Statement and Problem Formulation', level=1)
    add_paragraph(doc, "Design, implement, and evaluate a menu-driven Java application to manage a Smart Hospital Patient Appointment, Pharmacy Inventory, and Alert Notification System. Core entities such as Patient, Doctor/Appointment, Medicine, Inventory, and Notification must be modeled as encapsulated classes. The workflow includes registering entities, viewing schedules and stock, booking/canceling appointments, and multithreaded notification dispatching. We must use OOP concepts, Java Collections Framework (ArrayList, HashMap, Hashtable), Multithreading, and Exception Handling.")
    
    add_heading(doc, '2. Objective and Expected Outcomes', level=1)
    add_paragraph(doc, "- Automate hospital workflows for booking and inventory management.")
    add_paragraph(doc, "- Apply inheritance and polymorphism to handle different patient categories (fee waivers) and medicine dosage rules.")
    add_paragraph(doc, "- Implement robust data storage using the Java Collections Framework (Generics, Iterator, ListIterator).")
    add_paragraph(doc, "- Handle errors gracefully using custom exceptions.")
    add_paragraph(doc, "- Utilize multithreading and inter-thread communication (wait/notify) for real-time concurrent booking and alerts.")

    add_heading(doc, '3. Requirements, Constraints and Assumptions', level=1)
    add_paragraph(doc, "Requirements: Java 8+ environment, JDBC for persistence.")
    add_paragraph(doc, "Constraints: Limited inventory resources requiring synchronized access; doctors' time slots cannot overlap concurrently.")
    add_paragraph(doc, "Assumptions: Patient IDs are unique; doctors have predefined daily slots; the database (hospital.db) is locally available.")

    add_heading(doc, '4. Application of Relevant Course Knowledge / Concepts', level=1)
    add_paragraph(doc, "CO1: Encapsulation, inheritance (Regular, Senior, Pediatric patients), and polymorphism for calculating fees.")
    add_paragraph(doc, "CO2: Using ArrayList for schedules, HashMap/Hashtable for searching patients and tracking inventory, using Iterators for report generation.")
    add_paragraph(doc, "CO3: Implementing custom exceptions (e.g., DuplicateAppointmentException), and thread priority/synchronization for booking concurrent tasks and notification queues.")

    add_heading(doc, '5. Design / Proposed Solution / Methodology (Project Modules)', level=1)
    add_paragraph(doc, "The project is strictly modularized into 5 components for efficient team collaboration:")
    add_paragraph(doc, "Module 1: Core Entity Models & Database Setup. (Classes like Patient, Doctor, Medicine and Embedded JDBC configuration).")
    add_paragraph(doc, "Module 2: Data Persistence & Collections Framework Integration. (Service classes utilizing HashMaps, ArrayList, and Iterators for CRUD).")
    add_paragraph(doc, "Module 3: Concurrency, Threading & Exception Handling. (AppointmentBookingTask, synchronized slot management, and custom exception classes).")
    add_paragraph(doc, "Module 4: Notification System & Inter-thread Communication. (NotificationDispatcher, wait/notify mechanism for real-time alerts).")
    add_paragraph(doc, "Module 5: User Interface & Reporting. (ConsoleApp, Applet GUI, report generation algorithms).")

    add_heading(doc, '6. Algorithm / Pseudocode', level=1)
    code = """BEGIN
    LOAD records from JDBC database
    IF database empty THEN SEED demo data
    START notification dispatcher thread (wait/notify on shared queue)
    REPEAT
        DISPLAY menu
        READ choice
        CASE choice OF
            1: REGISTER patient (Regular / Senior / Pediatric)
            2-5: MANAGE doctors, medicines, and displays
            6: BOOK appointment (synchronized)
               IF no free slot THEN waitlist
               ELSE BOOK and ENQUEUE reminder
            12: DISPENSE medicine (synchronized)
               IF stock <= reorder THEN ENQUEUE LowStockNotification
        END CASE
    UNTIL choice = 0
END"""
    add_paragraph(doc, code)

    add_heading(doc, '7. Implementation / Source Code and Environment / Tools Used', level=1)
    add_paragraph(doc, "Environment: JDK 8+, Windows CMD/Powershell.")
    add_paragraph(doc, "Tools: Java Compiler (javac), Java Interpreter (java), AppletViewer for GUI, custom batch scripts for execution. Embedded DB via JDBC.")

    add_heading(doc, '8. Test Cases and Expected/Actual Results', level=1)
    add_paragraph(doc, "Test Case 1: Book available slot. Expected: Success and Reminder Enqueued. Actual: [Fill Result]")
    add_paragraph(doc, "Test Case 2: Book already booked slot. Expected: DuplicateAppointmentException thrown. Actual: [Fill Result]")
    add_paragraph(doc, "Test Case 3: Dispense beyond stock. Expected: OutOfStockException thrown. Actual: [Fill Result]")

    add_heading(doc, '9. Execution Screenshots / Outputs', level=1)
    add_paragraph(doc, "[Insert Screenshots of Console Menu, Applet, and Reports here]")

    add_heading(doc, '10. Results and Validation', level=1)
    add_paragraph(doc, "The application correctly limits doctor bookings and tracks inventory. The multithreaded notification system successfully dispatches alerts without blocking the main UI thread. [Insert Tables/Graphs of performance if any]")

    add_heading(doc, '11. Analysis, Comparison, Trade-offs and Justification', level=1)
    add_paragraph(doc, "Trade-offs: Used wait/notify over modern java.util.concurrent classes to strictly demonstrate CO3 syllabus requirements. Embedded DB is used for ease of setup over a dedicated server.")

    add_heading(doc, '12. Broader Considerations / SDG Relevance', level=1)
    add_paragraph(doc, "SDG 3 (Good Health): Automates hospital efficiency. SDG 10 (Reduced Inequalities): Encapsulated logic allows subsidized fees for Senior Citizens and Pediatric patients.")

    add_heading(doc, '13. Conclusion, Limitations and Possible Improvements', level=1)
    add_paragraph(doc, "Conclusion: A robust, multithreaded Java application was built successfully.")
    add_paragraph(doc, "Limitations: Applet is obsolete in modern browsers. Console UI is basic.")
    add_paragraph(doc, "Improvements: Migrate UI to JavaFX or a Web Frontend (Spring Boot).")

    add_heading(doc, '14. Individual Contribution of Group Members', level=1)
    add_paragraph(doc, "Team Member 1 ([Name]): Module 1 - Core Entity Models & Database Setup.")
    add_paragraph(doc, "Team Member 2 ([Name]): Module 2 - Data Persistence & Collections Framework Integration.")
    add_paragraph(doc, "Team Member 3 ([Name]): Module 3 - Concurrency, Threading & Exception Handling.")
    add_paragraph(doc, "Team Member 4 ([Name]): Module 4 - Notification System & Inter-thread Communication.")
    add_paragraph(doc, "Team Member 5 ([Name]): Module 5 - User Interface & Reporting.")

    add_heading(doc, '15. References', level=1)
    add_paragraph(doc, "1. Oracle Java SE Documentation (Collections, Concurrency)")
    add_paragraph(doc, "2. CSA09 Course Material")

    add_heading(doc, '16. One-Page Individual Reflection', level=1)
    add_paragraph(doc, "Reflection - Member 1: [Enter reflection here - Design decisions, challenges faced, learning gained, SDG connection]")
    doc.add_page_break()
    add_paragraph(doc, "Reflection - Member 2: [Enter reflection here]")
    doc.add_page_break()
    add_paragraph(doc, "Reflection - Member 3: [Enter reflection here]")
    doc.add_page_break()
    add_paragraph(doc, "Reflection - Member 4: [Enter reflection here]")
    doc.add_page_break()
    add_paragraph(doc, "Reflection - Member 5: [Enter reflection here]")

    doc.save('Assignment_Report_Template.docx')

if __name__ == '__main__':
    main()
