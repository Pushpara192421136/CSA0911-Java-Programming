Smart Hospital Java Assignment (CSA09)
=====================================

Problem: menu-driven Smart Hospital Patient Appointment, Pharmacy Inventory
and Alert Notification System, plus Applet GUI and JDBC persistence.

How to compile and run (Windows)
--------------------------------
1. Double-click compile.bat  (or: compile.bat from this folder)
2. Double-click run.bat      (console menu)
   Applet only:  run.bat --applet

Course outcomes covered
-----------------------
CO1  Classes, encapsulation, inheritance, polymorphism
     Patient -> Regular / Senior / Pediatric (consultation-fee waiver)
     Medicine -> Tablet / Syrup (dosage rules)
     Notification -> appointment reminder / low-stock alert
CO2  ArrayList, HashSet, HashMap, Hashtable, Iterator, ListIterator, generics
CO3  Custom exceptions, try-catch-finally, threads with priorities,
     synchronized booking/inventory, wait/notify notification queue

JDBC
----
DatabaseManager uses java.sql DriverManager, Connection, PreparedStatement
and ResultSet. Data is stored in hospital.db in this folder.

Applet
------
java.applet.Applet is not in JDK 9+. HospitalApplet extends
smarthospital.applet.Applet (init/start/stop/destroy) and is shown in
AppletViewer. Menu option 17 or: java -cp bin smarthospital.HospitalMain --applet

Demo data created on first run
------------------------------
Doctors D001-D003, medicines M001-M003, patients P001-P003.
Try booking P001 with D001 slot 09:00, then dispense M003 until a low-stock alert.

GitHub
------
Create a repo, add this folder (source + PSEUDOCODE.txt), and submit the link on GCR.
