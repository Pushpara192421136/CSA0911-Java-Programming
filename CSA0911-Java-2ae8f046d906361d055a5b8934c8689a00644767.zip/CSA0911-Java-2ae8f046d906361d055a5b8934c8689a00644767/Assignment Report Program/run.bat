@echo off
setlocal
cd /d "%~dp0"
if not exist bin\smarthospital\HospitalMain.class (
  call compile.bat
)
java -cp bin smarthospital.HospitalMain %*
endlocal
