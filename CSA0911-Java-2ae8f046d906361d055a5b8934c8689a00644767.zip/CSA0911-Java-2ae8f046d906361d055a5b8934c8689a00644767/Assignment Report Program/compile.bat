@echo off
setlocal
cd /d "%~dp0"
if not exist bin mkdir bin
javac --release 8 -Xlint:-options -encoding UTF-8 -d bin -sourcepath src src\smarthospital\HospitalMain.java src\smarthospital\ui\HospitalApplet.java
if errorlevel 1 (
  echo Compile failed.
  exit /b 1
)
echo Compile succeeded. Classes are in bin\
endlocal
